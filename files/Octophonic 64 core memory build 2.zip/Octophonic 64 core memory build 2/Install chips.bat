@echo off
rem  MY CHIPS - copies your four measured SID chips (.CHP) to the MiSTer's C64 folder
rem  (/media/fat/games/C64/My Chips), where Load My Chip finds them. Nothing is deleted.
rem  The password is 1 each time.
cd /d "%~dp0"
ssh -o StrictHostKeyChecking=accept-new root@MiSTer "mkdir -p '/media/fat/games/C64/My Chips'"
scp "My Chips\*.CHP" "root@MiSTer:/media/fat/games/C64/My Chips/"
echo.
echo Done. On the MiSTer: F12 - Audio ^& Video - Load My Chip: Left SIDs / Right SIDs - My Chips.
pause
