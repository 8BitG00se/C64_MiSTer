@echo off
rem  OCTOPHONIC 64 core memory build 2. Puts the new core on the MiSTer, hidden in _Computer
rem  (.C64_Octophonic_...rbf), where Computer - Octophonic 64 finds it.
rem  The core that was there is NOT deleted: it is moved to /media/fat/_Octophonic/old cores/
rem  so you can go back to it. The password is 1 each time.
cd /d "%~dp0"
for %%F in (C64_Octophonic_*.rbf) do set "RBF=%%F"
echo Keeping the old core in _Octophonic/old cores ...
ssh -o StrictHostKeyChecking=accept-new root@MiSTer "mkdir -p '/media/fat/_Octophonic/old cores'; for f in /media/fat/_Computer/.C64_Octophonic_*.rbf; do [ -e \"$f\" ] && mv \"$f\" '/media/fat/_Octophonic/old cores/'; done; ls '/media/fat/_Octophonic/old cores'"
echo Sending the new core (%RBF%) ...
scp "%RBF%" "root@MiSTer:/media/fat/_Computer/.%RBF%"
echo.
echo Done. On the MiSTer: Computer - Octophonic 64.
echo To go back: move the file from _Octophonic/old cores back into _Computer (with the dot).
pause
