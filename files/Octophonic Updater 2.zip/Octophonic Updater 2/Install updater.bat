@echo off
rem  OCTOPHONIC UPDATER 2 - puts the new updater in C:\Octophonic\Updater (your shortcuts keep working).
copy /Y "%~dp0Octophonic Updater.ps1" "C:\Octophonic\Updater\Octophonic Updater.ps1" >nul
echo Octophonic Updater 2 installed. It asks once where new demos should go (MiSTer SD card or network share).
