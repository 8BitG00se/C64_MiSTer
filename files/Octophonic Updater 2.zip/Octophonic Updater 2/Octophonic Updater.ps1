# OCTOPHONIC UPDATER 2
# Fetches every new Octophonic build from GitHub (8BitG00se/C64_MiSTer, branch "builds"), puts each
# zip in its folder under C:\Octophonic, unzips it, moves the build it replaces into C:\Octophonic\Old,
# and installs it:
#   - demos and C64 tools go either into your network share (as before) or STRAIGHT ONTO THE
#     MiSTer's SD card (games/C64/Octophonic/<Demos|Tools>/...) - you choose once, the first time
#   - core and OS builds ask "Install now? Y/N" first, because the MiSTer restarts
#   - the updater updates itself the same way
# At the end it shows "What's new and what to try" and leaves the same list on your Desktop.
# It never deletes anything. -Watch keeps checking every 3 minutes. -Setup asks the questions again.
param([switch]$Watch, [switch]$Setup, [string]$Base = 'C:\Octophonic', [string]$Source = 'https://raw.githubusercontent.com/8BitG00se/C64_MiSTer/builds')
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}
$Host.UI.RawUI.WindowTitle = 'Octophonic Updater 2'
$C64EXT = '.prg','.reu','.d64','.d81','.g64','.t64','.crt','.sid'
$SDLIB = '/media/fat/games/C64/Octophonic'

foreach ($f in 'Core','OS','Demos','Tools','Old','Updater') { New-Item -ItemType Directory -Path (Join-Path $Base $f) -Force | Out-Null }
$stateFile = Join-Path $Base 'Updater\state.json'
$setFile   = Join-Path $Base 'Updater\settings.json'
function Say($t, $c = 'Gray') { Write-Host $t -ForegroundColor $c }
function Load-State { if (Test-Path $stateFile) { try { return (Get-Content $stateFile -Raw | ConvertFrom-Json) } catch {} }; return [pscustomobject]@{ done = @() } }
function Save-State($s) { $s | ConvertTo-Json -Depth 4 | Set-Content -Path $stateFile -Encoding UTF8 }

function Get-Settings {
  if (-not $Setup -and (Test-Path $setFile)) { try { return (Get-Content $setFile -Raw | ConvertFrom-Json) } catch {} }
  Say ""; Say "Where should new demos and C64 tools go?" 'Cyan'
  Say "  1 = straight onto the MiSTer's SD card ($SDLIB) - no network folder needed"
  Say "  2 = into your network share (C:\MiSTerBridge\Games\C64\Octophonic) - the way it worked before"
  $a = Read-Host 'Type 1 or 2'
  $s = [pscustomobject]@{ deliver = $(if ($a -eq '2') { 'share' } else { 'sd' }) }
  $s | ConvertTo-Json | Set-Content -Path $setFile -Encoding UTF8
  Say "  Saved. (Run the updater with -Setup to change it.)" 'Green'
  return $s
}

function Move-ToOld($dir, $series, $keepName) {
  $old = Join-Path $Base 'Old'
  Get-ChildItem -LiteralPath $dir -Force -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -like "$series*" -and $_.Name -ne $keepName -and $_.Name -ne "$keepName.zip" } |
    ForEach-Object {
      $to = Join-Path $old $_.Name; $i = 2
      while (Test-Path -LiteralPath $to) { $to = Join-Path $old ("{0} ({1})" -f $_.Name, $i); $i++ }
      Move-Item -LiteralPath $_.FullName -Destination $to
      Say "    old build moved to Old: $($_.Name)" 'DarkGray'
    }
}

function Send-ToSD($folder, $cat, $series) {
  # one ssh connection (one password): tar sends the folder; older builds of the same series move to Old on the card
  $name = Split-Path $folder -Leaf; $parent = Split-Path $folder -Parent; $dest = "$SDLIB/$cat"
  $remote = "mkdir -p '$dest' '$SDLIB/Old' && cd '$dest' && find . -maxdepth 1 -mindepth 1 -name '$series*' ! -name '$name' -exec mv {} '$SDLIB/Old/' \; ; tar -xf - && sync && echo SENT"
  $cmdf = Join-Path $env:TEMP 'octo-send.cmd'
  "@echo off`r`ntar -cf - -C `"$parent`" `"$name`" | ssh -o StrictHostKeyChecking=accept-new -o ConnectTimeout=10 root@MiSTer `"$remote`"`r`n" | Set-Content -Path $cmdf -Encoding ASCII
  Say "    sending to the MiSTer's SD card: $dest/$name  (password 1)"
  $out = & cmd.exe /c $cmdf 2>&1
  Remove-Item $cmdf -ErrorAction SilentlyContinue
  if (($out -join ' ') -notmatch 'SENT') { throw "couldn't copy it to the MiSTer ($($out -join ' ')). Is it switched on?" }
}

function Check-Once {
  $state = Load-State; $done = @($state.done); $news = @()
  try { $man = Invoke-RestMethod -Uri ("$Source/manifest.json?t=" + [DateTime]::UtcNow.Ticks) -UseBasicParsing -TimeoutSec 30 }
  catch { Say "Can't reach GitHub right now ($($_.Exception.Message)). Try again in a minute." 'Red'; return 0 }
  $new = @($man.items | Where-Object { $done -notcontains $_.id })
  if ($new.Count -eq 0) { Say ("{0}  Up to date (builds list from {1})." -f (Get-Date -Format 'HH:mm'), $man.updated) 'Green'; return 0 }
  $set = Get-Settings

  Say ""; Say "NEW: $($new.Count) build(s)" 'Cyan'
  foreach ($it in $new) { Say ("  {0,-30} build {1,-4} -> {2}  {3}" -f $it.series, $it.build, $it.folder, $it.note) }
  try { [console]::Beep(880,120); [console]::Beep(1320,160) } catch {}

  foreach ($it in $new) {
    Say ""; Say "== $($it.series) build $($it.build)" 'Yellow'
    $dir = if ($it.dest) { $it.dest } else { Join-Path $Base $it.folder }
    New-Item -ItemType Directory -Path $dir -Force | Out-Null
    $zip = Join-Path $dir $it.file; $name = [IO.Path]::GetFileNameWithoutExtension($it.file)
    try {
      Say "    downloading $($it.file) ..."
      Invoke-WebRequest -Uri ("$Source/files/" + [uri]::EscapeDataString($it.file)) -OutFile $zip -UseBasicParsing -TimeoutSec 600
      if ($it.sha256 -and ((Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash -ne $it.sha256)) { throw 'the download is damaged (checksum does not match) - it will be tried again next time' }
      Move-ToOld $dir $it.series $name
      Say "    unzipping ..."
      Expand-Archive -LiteralPath $zip -DestinationPath $dir -Force
      $folder = Join-Path $dir $name; if (-not (Test-Path -LiteralPath $folder)) { $folder = $dir }
      $status = 'unzipped'
      $c64 = @(Get-ChildItem -LiteralPath $folder -File -ErrorAction SilentlyContinue | Where-Object { $C64EXT -contains $_.Extension.ToLower() })
      if ($c64.Count -gt 0 -and $set.deliver -eq 'sd' -and -not $it.ask) {
        Send-ToSD $folder $it.folder $it.series; $status = "on the MiSTer's SD card ($SDLIB/$($it.folder))"
      } elseif ($it.install) {
        $bat = Join-Path $folder $it.install
        if (-not (Test-Path -LiteralPath $bat)) { Say "    (no $($it.install) found - not installed)" 'Red' }
        else {
          $go = $true
          if ($it.ask) { Say "    This one restarts the MiSTer." 'Yellow'; $go = ((Read-Host "    Install $($it.series) build $($it.build) on the MiSTer now? Y/N") -eq 'Y') }
          if ($go) {
            Say "    installing (a window opens - the MiSTer password is 1) ..."
            Start-Process -FilePath 'cmd.exe' -ArgumentList '/c', "`"$bat`"" -WorkingDirectory $folder -Wait
            $status = 'installed'
          } else { $status = 'not installed'; Say "    Not installed. When ready, double-click: $bat" 'Yellow' }
        }
      }
      $done += $it.id; $state.done = $done; Save-State $state
      Say "    done ($status)" 'Green'
      $news += [pscustomobject]@{ it = $it; status = $status }
    } catch { Say "    FAILED: $($_.Exception.Message)" 'Red' }
  }

  if ($news.Count) {
    $txt = New-Object System.Collections.Generic.List[string]
    $txt.Add("OCTOPHONIC - WHAT'S NEW AND WHAT TO TRY   ($(Get-Date -Format 'dd MMM yyyy HH:mm'))"); $txt.Add('')
    foreach ($n in $news) {
      $txt.Add("$($n.it.series) build $($n.it.build)   [$($n.status)]")
      if ($n.it.note) { $txt.Add("   What it is : $($n.it.note)") }
      if ($n.it.try)  { $txt.Add("   Try this   : $($n.it.try)") }
      $txt.Add('')
    }
    Say ""; $txt | ForEach-Object { Say $_ 'Cyan' }
    $f = Join-Path ([Environment]::GetFolderPath('Desktop')) "Octophonic - what's new.txt"
    $txt | Set-Content -Path $f -Encoding UTF8
    Say "(saved on your Desktop: Octophonic - what's new.txt)" 'DarkGray'
  }
  return $new.Count
}

if ($Watch) {
  Say "Watching for new Octophonic builds every 3 minutes. Leave this window open (minimise it)." 'Cyan'
  while ($true) { [void](Check-Once); Start-Sleep -Seconds 180 }
} else {
  [void](Check-Once)
  Say ""; Read-Host 'Press Enter to close'
}
