@echo off
rem  OCTOPHONIC BROWSER COLOURS 1 - cartridges (.crt) in the F1 browser are now sky blue instead of orange.
rem  Copies the browser (SHELL.PRG) to the MiSTer's octophonic folder. Nothing else changes, no restart:
rem  the MiSTer reads the browser fresh each time you press F1. The password is 1.
cd /d "%~dp0"
echo Sending the browser to the MiSTer ...
scp -o StrictHostKeyChecking=accept-new "SHELL.PRG" root@MiSTer:/tmp/SHELL.PRG
if errorlevel 1 goto fail
ssh root@MiSTer "mkdir -p /media/fat/octophonic && mv /tmp/SHELL.PRG /media/fat/octophonic/SHELL.PRG && sync && echo OK"
if errorlevel 1 goto fail
echo.
echo Done. On the MiSTer press F1: .crt files are now sky blue.
pause
exit /b 0
:fail
echo.
echo Could not reach the MiSTer. Is it on and on the network? Then run this again.
pause
exit /b 1
