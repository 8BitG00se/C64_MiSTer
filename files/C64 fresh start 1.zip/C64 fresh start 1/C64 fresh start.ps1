# C64 FRESH START 1 - tidies C:\MiSTerBridge\Games\C64 for Octophonic OS.
# Nothing is deleted. Everything in the C64 folder is MOVED into C64\old (or old 2, old 3 ... if
# that already exists), EXCEPT "My Chips", which stays where it is. Then the new folders are made.
# It shows you the list first and only moves anything if you type Y.
$root = 'C:\MiSTerBridge\Games\C64'
if (-not (Test-Path $root)) { Write-Host "Can't find $root - nothing changed." -ForegroundColor Red; Read-Host 'Press Enter'; exit }

$old = Join-Path $root 'old'; $n = 2
while (Test-Path $old) { $old = Join-Path $root "old $n"; $n++ }
$keep  = @('My Chips')
$items = Get-ChildItem -LiteralPath $root -Force | Where-Object { $keep -notcontains $_.Name -and $_.Name -notmatch '^old( \d+)?$' }

Write-Host "These will be moved into $old :" -ForegroundColor Cyan
$items | ForEach-Object { Write-Host "  $($_.Name)" }
Write-Host "Staying put: My Chips (and any earlier 'old' folders)" -ForegroundColor Green
Write-Host "New folders: Octophonic, Games, Demos, Music" -ForegroundColor Green
if ((Read-Host 'Type Y and press Enter to go ahead') -ne 'Y') { Write-Host 'Nothing changed.'; Read-Host 'Press Enter'; exit }

New-Item -ItemType Directory -Path $old -Force | Out-Null
foreach ($i in $items) {
  try { Move-Item -LiteralPath $i.FullName -Destination $old -ErrorAction Stop; Write-Host "  moved: $($i.Name)" }
  catch { Write-Host "  could not move $($i.Name): $($_.Exception.Message)" -ForegroundColor Red }
}
foreach ($f in 'Octophonic','Games','Demos','Music','My Chips') { New-Item -ItemType Directory -Path (Join-Path $root $f) -Force | Out-Null }

Write-Host ""; Write-Host "Done. C64 now holds:" -ForegroundColor Cyan
Get-ChildItem -LiteralPath $root | ForEach-Object { Write-Host "  $($_.Name)" }
Write-Host "Next: run the Install to MiSTer.bat of each demo (Horizon, Lanterns) - they go into Octophonic." -ForegroundColor Green
Read-Host 'Press Enter to close'
