@echo off
rem  C64 FRESH START 1 - runs C64 fresh start.ps1 (it asks before moving anything).
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0C64 fresh start.ps1"
