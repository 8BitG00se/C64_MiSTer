@echo off
rem  Copies the demo in this folder to the MiSTer share, so the C64 core can load it:
rem  C:\MiSTerBridge\Games\C64\Octophonic\<this folder's name>
rem  It only adds that folder (and Octophonic if it isn't there). It never deletes anything.
setlocal
set "SHARE=C:\MiSTerBridge\Games\C64"
for %%I in ("%~dp0.") do set "NAME=%%~nxI"
set "DEST=%SHARE%\Octophonic\%NAME%"
if not exist "%SHARE%\" (
  echo The MiSTer share isn't at %SHARE% - nothing was copied.
  pause & exit /b 1
)
if not exist "%DEST%\" mkdir "%DEST%"
set N=0
for %%F in ("%~dp0*.d64" "%~dp0*.d81" "%~dp0*.reu" "%~dp0*.prg" "%~dp0*.crt" "%~dp0*.txt") do (
  copy /y "%%F" "%DEST%\" >nul && set /a N+=1 && echo   %%~nxF
)
echo.
echo Copied %N% file(s) to %DEST%
echo On the MiSTer: C64 core, F12, Load - Octophonic\%NAME%
pause
