# MAKE OCTOPHONIC SD 1
# Turns a MiSTer SD card into an Octophonic 64 card: it starts straight into Octophonic,
# with the demos, tools and your chips on the card itself - no network folder needed.
#   1 = make a FRESH card: downloads Mr. Fusion (the official MiSTer installer image) and
#       walks you through flashing it, then carries on with 2.
#   2 = add Octophonic to a MiSTer card that is in this PC now.
# Nothing is deleted. Your MiSTer program is kept as MiSTer.orig and MiSTer.ini as
# MiSTer.ini.before-octo, so the card can always go back to normal.
param([string]$Target, [switch]$Auto)   # -Target / -Auto: testing only
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}
$kit = Join-Path $PSScriptRoot 'OctoSD'
function Say($t, $c = 'Gray') { Write-Host $t -ForegroundColor $c }
function Ask($q) { if ($Auto) { return 'Y' } ; return (Read-Host $q) }

function Find-Card {
  if ($Target) { return $Target }
  while ($true) {
    $c = @()
    try { $c += Get-Volume -ErrorAction Stop | Where-Object { $_.FileSystemLabel -eq 'MiSTer_Data' -and $_.DriveLetter } | ForEach-Object { "$($_.DriveLetter):\" } } catch {}
    if (-not $c) { $c += Get-PSDrive -PSProvider FileSystem | Where-Object { (Test-Path (Join-Path $_.Root 'MiSTer')) -and (Test-Path (Join-Path $_.Root 'linux')) } | ForEach-Object { $_.Root } }
    $c = @($c | Select-Object -Unique)
    if ($c.Count -eq 1) { return $c[0] }
    if ($c.Count -gt 1) { $i = Ask ("More than one MiSTer card found: " + ($c -join ', ') + ". Type the drive letter to use"); return "$($i.TrimEnd(':','\')):\" }
    Say "No MiSTer card found. Put the MiSTer's SD card in this PC (the drive is called MiSTer_Data)." 'Yellow'
    if ((Ask 'Press Enter when it is in (or Q to quit)') -eq 'Q') { exit }
  }
}

function Has-Text($file, $text) {
  if (-not (Test-Path -LiteralPath $file)) { return $false }
  $b = [IO.File]::ReadAllBytes($file); $s = [Text.Encoding]::ASCII.GetString($b); return $s.Contains($text)
}

function Set-IniKey($lines, $key, $value, [switch]$OnlyIfMissing) {
  $sec = $false; $done = $false; $out = New-Object System.Collections.Generic.List[string]; $at = -1
  foreach ($l in $lines) {
    if ($l -match '^\s*\[(.+)\]') { $sec = ($matches[1] -eq 'MiSTer'); if ($sec) { $at = $out.Count } }
    if ($sec -and -not $done -and $l -match ("^\s*;?\s*" + [regex]::Escape($key) + "\s*=")) {
      if ($OnlyIfMissing -and $l -notmatch '^\s*;') { $out.Add($l); $done = $true; continue }
      $out.Add("$key=$value"); $done = $true; continue }
    $out.Add($l)
  }
  if (-not $done) { if ($at -ge 0) { $out.Insert($at + 1, "$key=$value") } else { $out.Insert(0, '[MiSTer]'); $out.Insert(1, "$key=$value") } }
  return ,$out
}

function Add-Octophonic($card) {
  Say ""; Say "Card: $card" 'Cyan'
  if (-not (Test-Path (Join-Path $card 'MiSTer'))) { Say "That card has no MiSTer program on it. Use option 1 to make a fresh card first." 'Red'; return }
  Say "This will put Octophonic on it (nothing is deleted):"
  Say "  - the MiSTer program becomes Octophonic Main (yours kept as MiSTer.orig)"
  Say "  - the Octophonic 64 core, its launchers and your chip presets"
  Say "  - your chips in games\C64\My Chips"
  Say "  - the library in games\C64\Octophonic (Demos, Games, Music, Paint, Tools)"
  Say "  - MiSTer.ini: VGA at 15 kHz for the CRT (copy kept as MiSTer.ini.before-octo)"
  if ((Ask 'Type Y and press Enter to go ahead') -ne 'Y') { Say 'Nothing changed.'; return }

  $mister = Join-Path $card 'MiSTer'; $orig = Join-Path $card 'MiSTer.orig'
  if (-not (Has-Text $mister 'Octophonic OS') -and -not (Test-Path $orig)) { Copy-Item $mister $orig; Say "  kept your MiSTer program as MiSTer.orig" }
  Copy-Item (Join-Path $kit 'MiSTer.octophonic') $mister -Force

  $comp = Join-Path $card '_Computer'; $old = Join-Path $card '_Octophonic\old cores'
  New-Item -ItemType Directory -Path $comp, $old -Force | Out-Null
  $new = Get-ChildItem -LiteralPath (Join-Path $kit '_Computer') -Force -Filter '.C64_Octophonic_*.rbf' | Select-Object -First 1
  Get-ChildItem -LiteralPath $comp -Force -Filter '.C64_Octophonic_*.rbf' | Where-Object { $_.Name -ne $new.Name } |
    ForEach-Object { Move-Item -LiteralPath $_.FullName -Destination (Join-Path $old $_.Name) -Force; Say "  older core moved to _Octophonic\old cores: $($_.Name)" }

  $osini = Join-Path $card 'octophonic\os.ini'; $keepIni = Test-Path $osini
  Get-ChildItem -LiteralPath $kit -Force | Where-Object { $_.Name -ne 'MiSTer.octophonic' } |
    ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination $card -Recurse -Force }
  if ($keepIni) { Say "  (an os.ini was already there - the kit's copy replaced it; start folder is now the SD library)" 'DarkGray' }

  $ini = Join-Path $card 'MiSTer.ini'; $ex = Join-Path $card 'MiSTer_example.ini'
  if (-not (Test-Path $ini) -and (Test-Path $ex)) { Copy-Item $ex $ini }
  if (Test-Path $ini) { if (-not (Test-Path "$ini.before-octo")) { Copy-Item $ini "$ini.before-octo" } ; $lines = Get-Content $ini } else { $lines = @('[MiSTer]') }
  $lines = Set-IniKey $lines 'vga_scaler' '0'
  $lines = Set-IniKey $lines 'forced_scandoubler' '0'
  $lines = Set-IniKey $lines 'video_mode' '0' -OnlyIfMissing
  Set-Content -Path $ini -Value $lines -Encoding ASCII
  Say "  MiSTer.ini set: vga_scaler=0, forced_scandoubler=0 (video_mode 720p if it wasn't set)"

  Say ""; Say "DONE. Put the card back in the MiSTer and switch on:" 'Green'
  Say "  it starts straight into Octophonic 64; F1 opens the library; CTRL+F12 leaves a demo." 'Green'
  Say "  Back to normal any time: rename MiSTer.orig to MiSTer on the card (or run 'Back to normal MiSTer.bat')." 'DarkGray'
}

function Fresh-Card {
  $dl = Join-Path $env:USERPROFILE 'Downloads'
  Say "Getting the newest Mr. Fusion (the official MiSTer installer image) ..." 'Cyan'
  try {
    $rel = Invoke-RestMethod 'https://api.github.com/repos/MiSTer-devel/mr-fusion/releases/latest' -UseBasicParsing -TimeoutSec 30
    $a = $rel.assets | Where-Object { $_.name -like '*.img.zip' } | Select-Object -First 1
    $zip = Join-Path $dl $a.name
    if (-not (Test-Path $zip)) { Invoke-WebRequest $a.browser_download_url -OutFile $zip -UseBasicParsing }
    Say "  saved: $zip" 'Green'
  } catch { Say "  Couldn't download it ($($_.Exception.Message)). Get it from github.com/MiSTer-devel/mr-fusion/releases" 'Red' }
  Say ""
  Say "NOW, BY HAND (this part can't be scripted safely):" 'Yellow'
  Say "  1. Open balenaEtcher (free: etcher.balena.io). Flash from file -> the Mr. Fusion zip above,"
  Say "     Select target -> your SD card (check it's the card!), Flash. Any card of 4 GB or more."
  Say "  2. Put the card in the MiSTer (network cable in), switch on. Mr. Fusion sets the card up"
  Say "     by itself (about 2 minutes) and restarts into the normal MiSTer menu."
  Say "  3. Switch the MiSTer off and put the card back in this PC."
  Ask 'Press Enter when the card is back in this PC' | Out-Null
  Add-Octophonic (Find-Card)
}

Say "MAKE OCTOPHONIC SD 1" 'Cyan'
if (Test-Path (Join-Path $kit 'octophonic\KIT.TXT')) { Get-Content (Join-Path $kit 'octophonic\KIT.TXT') | ForEach-Object { Say "  $_" 'DarkGray' } }
if ($Target) { Add-Octophonic $Target; return }
Say "  1 = make a FRESH card (Mr. Fusion + Octophonic)"
Say "  2 = add Octophonic to a MiSTer card that's in this PC now"
$c = Read-Host 'Type 1 or 2'
if ($c -eq '1') { Fresh-Card } elseif ($c -eq '2') { Add-Octophonic (Find-Card) } else { Say 'Nothing changed.' }
Read-Host 'Press Enter to close' | Out-Null
