@echo off
rem  MAKE OCTOPHONIC SD 1 - makes or upgrades a MiSTer SD card into an Octophonic 64 card (asks first).
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Make Octophonic SD.ps1"
