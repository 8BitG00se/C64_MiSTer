@echo off
rem  PC TIDY 2 - shows the plan, asks Y, then does the deeper tidy (see the top of PC tidy 2.ps1).
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0PC tidy 2.ps1"
