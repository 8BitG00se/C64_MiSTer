# UNDO PC TIDY (works for PC tidy 1 and 2) - puts back the files moved by the LAST PC tidy run (from its log). Asks first.
param([string]$LogDir)
if (-not $LogDir) { $LogDir = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'PC tidy logs' }
$log = Get-ChildItem -LiteralPath $LogDir -Filter 'tidy *.csv' -ErrorAction SilentlyContinue | Sort-Object Name | Select-Object -Last 1
if (-not $log) { Write-Host "No tidy log found in $LogDir - nothing to undo."; Read-Host 'Press Enter'; return }
$rows = Import-Csv -LiteralPath $log.FullName
Write-Host "This puts back $($rows.Count) files moved on $($log.BaseName -replace '^tidy ','')." -ForegroundColor Cyan
if ($env:PCTIDY_TEST -ne '1') { if ((Read-Host 'Type Y and press Enter to undo') -ne 'Y') { Write-Host 'Nothing changed.'; Read-Host 'Press Enter'; return } }
$ok = 0; $bad = 0
foreach ($r in $rows) {
  try {
    if (Test-Path -LiteralPath $r.From) { throw "something is already at $($r.From)" }
    New-Item -ItemType Directory -Path (Split-Path $r.From -Parent) -Force | Out-Null; Move-Item -LiteralPath $r.To -Destination $r.From -ErrorAction Stop; $ok++
  } catch { $bad++; Write-Host "  could not put back $($r.To): $($_.Exception.Message)" -ForegroundColor Red }
}
Rename-Item -LiteralPath $log.FullName -NewName ($log.Name -replace '\.csv$','.undone.csv')
Write-Host "Put back $ok files ($bad could not be). Empty sorting folders are left - delete them if you like." -ForegroundColor Green
if ($env:PCTIDY_TEST -ne '1') { Read-Host 'Press Enter to close' }
