# PC TIDY 2 - the deeper tidy. Shows the plan first, moves nothing until you type Y, deletes nothing,
# and logs every move so "Undo PC tidy.bat" can put the last run back.
#  1. Broken shortcuts: shortcuts on your Desktop and in your Start menu whose program no longer exists
#     go into Desktop\Sorted\Broken shortcuts. (Shortcuts to network or unplugged drives are left alone.)
#  2. Desktop: only shortcuts stay on the Desktop itself. Loose files - and the type folders PC tidy 1
#     made (Pictures, Zips, C64 ...) - go into ONE folder: Desktop\Sorted.
#  3. Old builds: zips with a build number (e.g. "Octophonic Horizon build 7.zip") - the newest of each
#     series stays, the older ones go into Zips\Old builds.
#  4. Duplicates: files with exactly the same contents - one copy stays, the others go into Duplicates.
#  5. Loose .exe files: installers go into Installers, programs that run on their own into Programs,
#     loose .bat/.cmd/.ps1 into Scripts.
# Only LOOSE files are touched (on the Desktop, in Downloads, in Documents, and inside the type folders
# PC tidy made). Nothing inside any other folder is ever moved, so programs and build .bats keep working.
param([string]$Test)   # testing only: "Desktop=...,Downloads=...,Documents=...,StartMenu=...,Logs=..."
$ErrorActionPreference = 'Continue'

$types = [ordered]@{
  'Pictures'    = 'jpg','jpeg','png','gif','bmp','webp','heic','tif','tiff','svg','psd','ico','gsc'
  'Videos'      = 'mp4','mkv','mov','avi','webm','wmv','m4v','flv','mpg','mpeg'
  'Music'       = 'mp3','wav','flac','ogg','m4a','aac','wma','mid','midi','opus'
  'Documents'   = 'pdf','doc','docx','txt','rtf','odt','xls','xlsx','csv','ppt','pptx','md','epub','html','htm'
  'Zips'        = 'zip','7z','rar','tar','gz','tgz','bz2','xz'
  'Installers'  = 'msi','msix','appx','msixbundle'
  'Scripts'     = 'bat','cmd','ps1','vbs'
  'C64'         = 'd64','d71','d81','g64','t64','prg','crt','reu','sid','tap','vsf','chp','kla','oct'
  'MiSTer'      = 'rbf','mgl','mra'
  'Code'        = 'py','js','css','json','asm','s','c','cpp','h','hpp','cs','java','sh','xml','yml','yaml','ini','cfg','vhd','sv','v'
  'Disk images' = 'iso','img','vhdx','bin','cue','chd'
}
$typeNames = @($types.Keys) + 'Programs','Other','Documents sorted'
$ext2type = @{}; foreach ($k in $types.Keys) { foreach ($e in $types[$k]) { if (-not $ext2type.ContainsKey($e)) { $ext2type[$e] = $k } } }
$skipExt = 'lnk','url','crdownload','part','partial','tmp','download','opdownload'
$cutoff = (Get-Date).AddMinutes(-10)

# ---- places
$P = @{}
if ($Test) { foreach ($kv in ($Test -split ',')) { $k,$v = $kv -split '=',2; $P[$k] = $v } }
else {
  $P.Desktop   = [Environment]::GetFolderPath('Desktop')
  $P.Documents = [Environment]::GetFolderPath('MyDocuments')
  $P.StartMenu = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'
  $dl = $null; try { $dl = (Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders' -ErrorAction Stop).'{374DE290-123F-4565-9164-39C4925E467B}' } catch {}
  $P.Downloads = if ($dl) { [Environment]::ExpandEnvironmentVariables($dl) } else { Join-Path $env:USERPROFILE 'Downloads' }
  $P.Logs      = Join-Path $P.Documents 'PC tidy logs'
}
$sorted = Join-Path $P.Desktop 'Sorted'

function Get-LnkTarget($path) {
  if ($Test) { $t = (Get-Content -LiteralPath $path -Raw); if ($t -match 'TARGET:(.*)') { return $matches[1].Trim() } ; return '' }
  try { $sh = New-Object -ComObject WScript.Shell; return [Environment]::ExpandEnvironmentVariables($sh.CreateShortcut($path).TargetPath) } catch { return '' }
}
function Is-Broken($target) {
  if (-not $target) { return $false }                       # store apps / special shortcuts: no file target
  if ($target -match '^(\\\\|[a-z]+:)//') { return $false }   # network paths / URLs
  if ($target.StartsWith('\\')) { return $false }
  $root = [IO.Path]::GetPathRoot($target)
  if ($root -and -not (Test-Path -LiteralPath $root)) { return $false }  # unplugged drive: leave it
  return -not (Test-Path -LiteralPath $target)
}
function Is-Installer($f) {
  if ($f.Name -match '(?i)setup|install|redist|vc_?redist|update|patch|_x64\.exe$|_x86\.exe$|-win(64|32)?-') { return $true }
  try { $vi = $f.VersionInfo; if (("$($vi.FileDescription) $($vi.ProductName) $($vi.InternalName)") -match '(?i)setup|install') { return $true } } catch {}
  return $false
}
function Loose($dir) {
  if (-not (Test-Path -LiteralPath $dir)) { return @() }
  Get-ChildItem -LiteralPath $dir -File -Force -ErrorAction SilentlyContinue | Where-Object {
    -not ($_.Attributes -band [IO.FileAttributes]::Hidden) -and -not ($_.Attributes -band [IO.FileAttributes]::System) -and
    $_.Name -ne 'desktop.ini' -and $_.LastWriteTime -lt $cutoff }
}
function TypeOf($f) {
  $e = $f.Extension.TrimStart('.').ToLower()
  if ($e -eq 'exe') { if (Is-Installer $f) { return 'Installers' } else { return 'Programs' } }
  if ($ext2type.ContainsKey($e)) { return $ext2type[$e] } else { return 'Other' }
}

$plan = @{}      # from -> [pscustomobject]
function Add-Move($file, $dir, $why) { if (-not $plan.ContainsKey($file.FullName)) { $plan[$file.FullName] = [pscustomobject]@{ File = $file; Dir = $dir; Why = $why } } }

# ---- 1. broken shortcuts
$lnks = @()
$lnks += Get-ChildItem -LiteralPath $P.Desktop -Filter *.lnk -File -ErrorAction SilentlyContinue
if ($P.StartMenu -and (Test-Path -LiteralPath $P.StartMenu)) { $lnks += Get-ChildItem -LiteralPath $P.StartMenu -Filter *.lnk -File -Recurse -ErrorAction SilentlyContinue }
foreach ($l in $lnks) { if (Is-Broken (Get-LnkTarget $l.FullName)) { Add-Move $l (Join-Path $sorted 'Broken shortcuts') 'Broken shortcuts' } }

# ---- gather the loose files we may touch
$desk = @(Loose $P.Desktop | Where-Object { $skipExt -notcontains $_.Extension.TrimStart('.').ToLower() })
$deskTypeDirs = @(Get-ChildItem -LiteralPath $P.Desktop -Directory -ErrorAction SilentlyContinue | Where-Object { $typeNames -contains $_.Name })
$deskInType = @(); foreach ($d in $deskTypeDirs) { $deskInType += Loose $d.FullName }
$dlLoose = @(Loose $P.Downloads | Where-Object { $skipExt -notcontains $_.Extension.TrimStart('.').ToLower() })
$dlInType = @(); foreach ($n in $typeNames) { $dlInType += Loose (Join-Path $P.Downloads $n) }
$docLoose = @(Loose $P.Documents | Where-Object { $skipExt -notcontains $_.Extension.TrimStart('.').ToLower() })

# ---- 4. duplicates (same size, then same SHA256) across Desktop + Downloads + Documents loose files
$pool = @($desk + $deskInType + $dlLoose + $dlInType + $docLoose) | Where-Object { $_.Length -gt 0 -and $_.Length -lt 4GB }
foreach ($g in ($pool | Group-Object Length | Where-Object Count -gt 1)) {
  foreach ($h in ($g.Group | ForEach-Object { [pscustomobject]@{ F = $_; H = (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash } } | Group-Object H | Where-Object Count -gt 1)) {
    $keep = $h.Group | Sort-Object { $_.F.Name -match '\(\d+\)' }, { $_.F.Name.Length }, { $_.F.LastWriteTime } | Select-Object -First 1
    foreach ($x in $h.Group) { if ($x.F.FullName -ne $keep.F.FullName) {
      $base = if ($x.F.FullName.StartsWith($P.Downloads)) { $P.Downloads } elseif ($x.F.FullName.StartsWith($P.Documents)) { $P.Documents } else { $sorted }
      Add-Move $x.F (Join-Path $base 'Duplicates') 'Duplicates' } }
  }
}

# ---- 3. old builds: "<series> <number>.zip" - newest number of each series stays
$zips = @($desk + $deskInType + $dlLoose + $dlInType) | Where-Object { $_.Extension -ieq '.zip' -and -not $plan.ContainsKey($_.FullName) }
$series = @{}
foreach ($z in $zips) {
  if ($z.BaseName -match '^(.*?)[\s_\-]*(?:build|b|v|rev|r)?[\s_\-]*(\d+)$') {
    $key = ($matches[1].ToLower() -replace '[\s_\-]+',' ').Trim(); if (-not $key) { continue }
    if (-not $series[$key]) { $series[$key] = @() }; $series[$key] += [pscustomobject]@{ F = $z; N = [int64]$matches[2] }
  }
}
foreach ($k in $series.Keys) {
  $list = $series[$k]; if ($list.Count -lt 2) { continue }
  $max = ($list | Measure-Object N -Maximum).Maximum
  foreach ($x in $list) { if ($x.N -lt $max) {
    $base = if ($x.F.FullName.StartsWith($P.Downloads)) { Join-Path $P.Downloads 'Zips' } else { Join-Path $sorted 'Zips' }
    Add-Move $x.F (Join-Path $base 'Old builds') 'Old builds' } }
}

# ---- 2 + 5. type sorting: Desktop -> Desktop\Sorted\<type>; Downloads -> Downloads\<type>; Documents -> Documents\<type>
foreach ($f in ($desk + $deskInType)) { if (-not $plan.ContainsKey($f.FullName)) {
  $t = TypeOf $f
  $from = Split-Path $f.FullName -Parent; $fromType = Split-Path $from -Leaf
  if ($from -ne $P.Desktop -and $typeNames -contains $fromType -and ($fromType -eq $t -or $t -eq 'Other')) { $t = $fromType }
  Add-Move $f (Join-Path $sorted $t) "Desktop -> Sorted" } }
foreach ($f in ($dlLoose + $dlInType)) { if (-not $plan.ContainsKey($f.FullName)) {
  $t = TypeOf $f; $target = Join-Path $P.Downloads $t
  if ((Split-Path $f.FullName -Parent) -ne $target) { Add-Move $f $target "Downloads by type" } } }
foreach ($f in $docLoose) { if (-not $plan.ContainsKey($f.FullName)) {
  $t = TypeOf $f; if ($t -eq 'Documents') { $t = 'Documents sorted' }
  Add-Move $f (Join-Path $P.Documents $t) "Documents by type" } }

# ---- show the plan
if ($plan.Count -eq 0) { Write-Host 'Nothing to tidy - all neat already.' -ForegroundColor Green; if (-not $Test) { Read-Host 'Press Enter' }; return }
Write-Host ""; Write-Host "PLAN - $($plan.Count) files will be moved:" -ForegroundColor Cyan
foreach ($g in ($plan.Values | Group-Object Why | Sort-Object Name)) {
  Write-Host ("  {0}  ({1} files)" -f $g.Name, $g.Count) -ForegroundColor Yellow
  if ($g.Name -in 'Broken shortcuts','Old builds','Duplicates') { $g.Group | Select-Object -First 12 | ForEach-Object { Write-Host "     $($_.File.Name)" }; if ($g.Count -gt 12) { Write-Host "     ... and $($g.Count - 12) more" } }
  else { foreach ($s in ($g.Group | Group-Object { Split-Path $_.Dir -Leaf } | Sort-Object Name)) { Write-Host ("     {0,-20} {1,5}" -f $s.Name, $s.Count) } }
}
Write-Host "Shortcuts that work stay on the Desktop. Nothing inside your other folders is touched. Nothing is deleted." -ForegroundColor Green
$go = if ($Test) { 'Y' } else { Read-Host 'Type Y and press Enter to tidy' }
if ($go -ne 'Y') { Write-Host 'Nothing changed.'; Read-Host 'Press Enter'; return }

New-Item -ItemType Directory -Path $P.Logs -Force | Out-Null
$log = Join-Path $P.Logs ("tidy " + (Get-Date -Format 'yyyy-MM-dd HHmmss') + ".csv")
$done = New-Object System.Collections.Generic.List[object]; $fail = 0
foreach ($m in $plan.Values) {
  try {
    New-Item -ItemType Directory -Path $m.Dir -Force -ErrorAction Stop | Out-Null
    $to = Join-Path $m.Dir $m.File.Name
    if (Test-Path -LiteralPath $to) { $b = $m.File.BaseName; $x = $m.File.Extension; $i = 2; do { $to = Join-Path $m.Dir "$b ($i)$x"; $i++ } while (Test-Path -LiteralPath $to) }
    Move-Item -LiteralPath $m.File.FullName -Destination $to -ErrorAction Stop
    $done.Add([pscustomobject]@{ From = $m.File.FullName; To = $to })
  } catch { $fail++; Write-Host "  could not move $($m.File.Name): $($_.Exception.Message)" -ForegroundColor Red }
}
$done | Export-Csv -LiteralPath $log -NoTypeInformation -Encoding UTF8
# type folders PC tidy 1 left on the Desktop are now empty - remove only if completely empty
foreach ($d in $deskTypeDirs) { if ((Test-Path -LiteralPath $d.FullName) -and -not (Get-ChildItem -LiteralPath $d.FullName -Force)) { Remove-Item -LiteralPath $d.FullName } }
Write-Host ""; Write-Host "Done: $($done.Count) moved, $fail could not be moved (probably open in a program)." -ForegroundColor Green
Write-Host "Broken shortcuts and duplicates are in folders, not deleted - check them, then delete them yourself if you're happy."
Write-Host "Undo: Undo PC tidy.bat  (log: $log)"
if (-not $Test) { Read-Host 'Press Enter to close' }
