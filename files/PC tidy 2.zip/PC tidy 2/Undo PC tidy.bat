@echo off
rem  UNDO PC TIDY - puts back the files from the last PC tidy run (asks first).
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Undo PC tidy.ps1"
