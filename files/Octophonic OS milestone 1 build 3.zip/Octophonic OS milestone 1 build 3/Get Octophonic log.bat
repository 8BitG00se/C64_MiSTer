@echo off
rem  OCTOPHONIC OS - copies the OS's log (every request the C64 made, and what Main did) from the
rem  MiSTer into this folder, as os.log. Send me that file. The password is 1.
cd /d "%~dp0"
scp -o StrictHostKeyChecking=accept-new root@MiSTer:/media/fat/octophonic/os.log "os.log"
scp root@MiSTer:/media/fat/octophonic/os.log.1 "os.log.1" 2>nul
echo.
if exist os.log (echo os.log is in this folder now - send it over.) else (echo No log came back - is the MiSTer on, and was the OS started?)
pause
