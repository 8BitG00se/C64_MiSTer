# SEND OCTOPHONIC REPORT 1 - puts everything Claude needs into ONE zip on your Desktop:
#  - the demos' screenshots and self-test reports from your share
#    (C:\MiSTerBridge\Games\C64\Octophonic\Screenshots): all of them if they're small, otherwise the
#    newest test run (the most recently changed folder) plus today's manual (CTRL+F11) shots
#  - the MiSTer's Octophonic log and settings (os.log, os.ini) - it asks for the MiSTer password (1)
# Then it opens Explorer with the zip selected: drag that one file into the chat.
# It only reads and copies - nothing is changed or deleted.
param([string]$Shots = 'C:\MiSTerBridge\Games\C64\Octophonic\Screenshots')
$ErrorActionPreference = 'Continue'
$ProgressPreference = 'SilentlyContinue'
$stamp = Get-Date -Format 'yyyy-MM-dd HHmm'
$work = Join-Path $env:TEMP "Octophonic report $stamp"
Remove-Item -LiteralPath $work -Recurse -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Path $work -Force | Out-Null
$notes = New-Object System.Collections.Generic.List[string]
$notes.Add("Octophonic report $stamp")

if (Test-Path -LiteralPath $Shots) {
  $all = @(Get-ChildItem -LiteralPath $Shots -Recurse -File -ErrorAction SilentlyContinue)
  $size = ($all | Measure-Object Length -Sum).Sum
  if ($size -lt 40MB) { $pick = $all; $notes.Add("screenshots: all $($all.Count) files ($([math]::Round($size/1MB,1)) MB)") }
  else {
    $newest = Get-ChildItem -LiteralPath $Shots -Directory | Where-Object Name -ne 'Manual' | Sort-Object LastWriteTime | Select-Object -Last 1
    $pick = @()
    if ($newest) { $pick += Get-ChildItem -LiteralPath $newest.FullName -Recurse -File }
    $man = Join-Path $Shots 'Manual'
    if (Test-Path $man) { $pick += Get-ChildItem -LiteralPath $man -File | Where-Object LastWriteTime -gt (Get-Date).AddDays(-1) }
    $pick += Get-ChildItem -LiteralPath $Shots -File | Where-Object LastWriteTime -gt (Get-Date).AddDays(-1)
    $notes.Add("screenshots: newest run '$($newest.Name)' + today's manual shots ($($pick.Count) files; all of them would be $([math]::Round($size/1MB)) MB)")
  }
  foreach ($f in $pick) {
    $rel = $f.FullName.Substring($Shots.Length).TrimStart('\')
    $to = Join-Path (Join-Path $work 'Screenshots') $rel
    New-Item -ItemType Directory -Path (Split-Path $to) -Force | Out-Null
    Copy-Item -LiteralPath $f.FullName -Destination $to
  }
} else { $notes.Add("no screenshots folder at $Shots") }

Write-Host "Reading the Octophonic log from the MiSTer - type the password 1 if asked ..." -ForegroundColor Cyan
if (Test-Connection -ComputerName MiSTer -Count 1 -Quiet -ErrorAction SilentlyContinue) {
  $log = & ssh -o StrictHostKeyChecking=accept-new -o ConnectTimeout=10 root@MiSTer "cd /media/fat/octophonic && echo '== os.ini' && cat os.ini && echo && echo '== cores' && ls -la /media/fat/_Computer | grep -i octo && echo && echo '== os.log.1 (older)' && tail -200 os.log.1 2>/dev/null; echo && echo '== os.log' && cat os.log" 2>&1
  $log | Set-Content -Path (Join-Path $work 'MiSTer os.log.txt') -Encoding UTF8
  $notes.Add("MiSTer log: $($log.Count) lines")
} else { $notes.Add("the MiSTer didn't answer on the network - no log") }

$notes | Set-Content -Path (Join-Path $work 'README.txt') -Encoding UTF8
$zip = Join-Path ([Environment]::GetFolderPath('Desktop')) "Octophonic report $stamp.zip"
Compress-Archive -Path (Join-Path $work '*') -DestinationPath $zip -Force
Remove-Item -LiteralPath $work -Recurse -Force -ErrorAction SilentlyContinue
Write-Host "Made: $zip" -ForegroundColor Green
Write-Host "Drag that file into the chat." -ForegroundColor Green
Start-Process explorer.exe "/select,`"$zip`""
