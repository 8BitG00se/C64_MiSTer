@echo off
rem  OCTOPHONIC OS - back to the normal MiSTer: your own MiSTer program (MiSTer.orig) goes back,
rem  octophonic/os.ini is taken away, and the MiSTer restarts. The Octophonic core stays, so
rem  Computer - Octophonic 64 still works from the menu. The password is 1.
ssh -o StrictHostKeyChecking=accept-new root@MiSTer "cd /media/fat && if [ -e MiSTer.orig ]; then cp MiSTer.orig MiSTer.new && mv MiSTer.new MiSTer && echo Your MiSTer program is back.; else echo No MiSTer.orig - the MiSTer program was left as it is.; fi; rm -f octophonic/os.ini; sync; (sleep 1; reboot) &"
echo.
echo Done. The MiSTer is restarting into its normal menu.
pause
