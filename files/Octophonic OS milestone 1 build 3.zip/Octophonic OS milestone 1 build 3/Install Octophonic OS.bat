@echo off
rem  OCTOPHONIC OS - milestone 1, build 3. Makes the MiSTer start straight into Octophonic 64.
rem  It changes these things on the MiSTer's SD card, and deletes nothing:
rem    1. the MiSTer program: a copy of yours is kept as MiSTer.orig, then ours goes in its place
rem    2. the core: core build 6 goes into _Computer (the core that was there moves to
rem       _Octophonic/old cores, as with every core build)
rem    3. octophonic/os.ini (kept if it is already there) and octophonic/SHELL.PRG (the browser)
rem    4. the Octophonic 64 launcher and the four chip presets in _Computer
rem    5. your chips, copied to games/C64/My Chips (again - nothing is lost if they are there)
rem  Then the MiSTer restarts. "Back to normal MiSTer.bat" undoes it. The password is 1 each time.
cd /d "%~dp0files"
for %%F in (C64_Octophonic_*.rbf) do set "RBF=%%F"
echo Sending the files ...
scp -o StrictHostKeyChecking=accept-new "MiSTer" root@MiSTer:/media/fat/MiSTer.octo
if errorlevel 1 goto fail
scp "%RBF%" "root@MiSTer:/tmp/%RBF%"
scp "os.ini.txt" root@MiSTer:/tmp/os.ini
scp "SHELL.PRG" root@MiSTer:/tmp/SHELL.PRG
ssh root@MiSTer "mkdir -p '/media/fat/games/C64/My Chips' /media/fat/_Computer"
scp "_Computer\*.mgl" "root@MiSTer:/media/fat/_Computer/"
scp "My Chips\*.CHP" "root@MiSTer:/media/fat/games/C64/My Chips/"
echo Putting them in place, then restarting the MiSTer ...
ssh root@MiSTer "cd /media/fat && (grep -q 'Octophonic OS' MiSTer || cp MiSTer MiSTer.orig) && chmod +x MiSTer.octo && mv MiSTer.octo MiSTer && mkdir -p '_Octophonic/old cores' && for f in _Computer/.C64_Octophonic_*.rbf; do [ -e \"$f\" ] && mv \"$f\" '_Octophonic/old cores/'; done; mv '/tmp/%RBF%' '_Computer/.%RBF%' && mkdir -p octophonic && ([ -e octophonic/os.ini ] || mv /tmp/os.ini octophonic/os.ini) && mv /tmp/SHELL.PRG octophonic/SHELL.PRG && sync && echo OK && (sleep 1; reboot) &"
echo.
echo Done. The MiSTer is restarting: in about 15 seconds it should come up on the
echo Octophonic 64 V1.1 screen with no menu. See How to test.txt.
pause
exit /b
:fail
echo.
echo That didn't reach the MiSTer - nothing was changed. Check it is on and on the network.
pause
