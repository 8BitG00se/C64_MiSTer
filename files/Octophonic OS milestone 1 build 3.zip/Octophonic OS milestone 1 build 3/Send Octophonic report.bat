@echo off
rem  SEND OCTOPHONIC REPORT 1 - one zip on your Desktop with the screenshots, the self-test reports
rem  and the MiSTer's Octophonic log (password 1). Reads only - changes nothing. Drag the zip into the chat.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Send Octophonic report.ps1"
pause
