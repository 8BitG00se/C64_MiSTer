# SOUND FIX 1 - brings back the audio jack and the soundbar (EP-HDMI-RX over the NVIDIA HDMI) after
# HDMI cables were swapped. It deletes nothing and changes no settings files. It only:
#   1. shows every sound device Windows knows about (including hidden and switched-off ones)
#   2. switches back on any sound device that is turned off
#   3. restarts the NVIDIA and Realtek sound drivers, so they look at the cables again
#   4. asks Windows to re-check all devices
#   5. restarts the Windows sound service
#   6. shows the list again and opens the Sound window so you can pick the default
$ErrorActionPreference = 'Continue'
function Show-Audio($title) {
  Write-Host ""; Write-Host "=== $title ===" -ForegroundColor Cyan
  Get-PnpDevice -Class AudioEndpoint -ErrorAction SilentlyContinue |
    Sort-Object Status, FriendlyName |
    Format-Table -AutoSize @{n='Status';e={$_.Status}}, @{n='Sound device';e={$_.FriendlyName}} | Out-String | Write-Host
}
Show-Audio "Sound devices BEFORE"

Write-Host "Switching on any sound devices that are turned off ..." -ForegroundColor Yellow
Get-PnpDevice -Class AudioEndpoint, MEDIA -ErrorAction SilentlyContinue |
  Where-Object { $_.Status -eq 'Error' -and $_.ConfigManagerErrorCode -eq 22 } |   # 22 = disabled
  ForEach-Object { Write-Host "  on: $($_.FriendlyName)"; Enable-PnpDevice -InstanceId $_.InstanceId -Confirm:$false -ErrorAction SilentlyContinue }

Write-Host "Restarting the sound drivers (NVIDIA HDMI, Realtek and others) ..." -ForegroundColor Yellow
Get-PnpDevice -Class MEDIA -PresentOnly -ErrorAction SilentlyContinue |
  Where-Object { $_.FriendlyName -match 'NVIDIA High Definition Audio|Realtek|High Definition Audio|USB Audio' } |
  ForEach-Object {
    Write-Host "  restart: $($_.FriendlyName)"
    Disable-PnpDevice -InstanceId $_.InstanceId -Confirm:$false -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 2
    Enable-PnpDevice  -InstanceId $_.InstanceId -Confirm:$false -ErrorAction SilentlyContinue
  }

Write-Host "Asking Windows to re-check all devices ..." -ForegroundColor Yellow
pnputil /scan-devices | Out-Null
Start-Sleep -Seconds 3

Write-Host "Restarting the Windows sound service ..." -ForegroundColor Yellow
Restart-Service -Name AudioEndpointBuilder -Force -ErrorAction SilentlyContinue
Restart-Service -Name Audiosrv -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 3

Show-Audio "Sound devices AFTER"
Write-Host "OK = working.  Unknown = Windows knows it but can't see it now (cable/soundbar off)." -ForegroundColor Green
Write-Host "Opening the Sound window: right-click the device you want -> Set as Default Device." -ForegroundColor Green
Start-Process mmsys.cpl
