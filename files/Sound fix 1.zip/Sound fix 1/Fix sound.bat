@echo off
rem  SOUND FIX 1 - runs Fix sound.ps1 as administrator (Windows will ask "Yes" once).
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process powershell -Verb RunAs -ArgumentList '-NoProfile -ExecutionPolicy Bypass -NoExit -File ""%~dp0Fix sound.ps1""'"
