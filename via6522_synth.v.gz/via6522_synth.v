module iecdrv_via6522
  (input  clock,
   input  rising,
   input  falling,
   input  reset,
   input  [3:0] addr,
   input  wen,
   input  ren,
   input  [7:0] data_in,
   input  [7:0] port_a_i,
   input  [7:0] port_b_i,
   input  ca1_i,
   input  ca2_i,
   input  cb1_i,
   input  cb2_i,
   output [7:0] data_out,
   output phi2_ref,
   output [7:0] port_a_o,
   output [7:0] port_a_t,
   output [7:0] port_b_o,
   output [7:0] port_b_t,
   output ca2_o,
   output ca2_t,
   output cb1_o,
   output cb1_t,
   output cb2_o,
   output cb2_t,
   output irq);
  wire [31:0] pio_i;
  reg [7:0] port_a_c;
  reg [7:0] port_b_c;
  reg [6:0] irq_mask;
  reg [6:0] irq_flags;
  reg [6:0] irq_events;
  wire irq_out;
  reg [15:0] timer_a_latch;
  reg [15:0] timer_b_latch;
  reg [15:0] timer_a_count;
  reg [15:0] timer_b_count;
  wire timer_a_out;
  wire timer_b_tick;
  reg [7:0] acr;
  reg [7:0] pcr;
  reg [7:0] shift_reg;
  wire serport_en;
  wire ser_cb2_o;
  wire hs_cb2_o;
  wire cb1_t_int;
  wire cb1_o_int;
  wire cb2_t_int;
  wire cb2_o_int;
  reg [7:0] ira;
  reg [7:0] irb;
  wire write_t1c_l;
  wire write_t1c_h;
  wire write_t2c_h;
  wire ca1_c;
  wire ca2_c;
  wire cb1_c;
  wire cb2_c;
  wire ca1_d1;
  wire ca2_d1;
  wire cb1_d1;
  wire cb2_d1;
  wire ca1_d2;
  wire ca2_d2;
  wire cb1_d2;
  wire cb2_d2;
  wire ca2_handshake_o;
  wire ca2_pulse_o;
  wire cb2_handshake_o;
  wire cb2_pulse_o;
  wire shift_active;
  wire n30_o;
  wire n32_o;
  wire n33_o;
  wire n34_o;
  wire n35_o;
  wire n36_o;
  wire n40_o;
  wire n41_o;
  wire n42_o;
  wire n43_o;
  wire n47_o;
  wire n48_o;
  wire n49_o;
  wire n50_o;
  wire n52_o;
  wire n53_o;
  wire n54_o;
  wire n55_o;
  wire n56_o;
  wire n57_o;
  wire n58_o;
  wire n59_o;
  wire n60_o;
  wire n61_o;
  wire n62_o;
  wire n63_o;
  wire n64_o;
  wire n65_o;
  wire n66_o;
  wire n67_o;
  wire n68_o;
  wire n69_o;
  wire n70_o;
  wire n71_o;
  wire n72_o;
  wire n73_o;
  wire n74_o;
  wire [1:0] n75_o;
  wire n77_o;
  wire n79_o;
  wire n82_o;
  wire [2:0] n84_o;
  reg n85_o;
  wire [1:0] n86_o;
  wire n88_o;
  wire n90_o;
  wire n93_o;
  wire [2:0] n95_o;
  reg n96_o;
  wire [6:0] n99_o;
  wire n101_o;
  wire n104_o;
  wire n110_o;
  wire n112_o;
  wire n118_o;
  wire n119_o;
  wire n120_o;
  wire n121_o;
  wire n122_o;
  wire n124_o;
  wire n125_o;
  wire n126_o;
  wire n127_o;
  wire n128_o;
  wire n130_o;
  wire n131_o;
  wire n133_o;
  wire n134_o;
  wire n135_o;
  wire n137_o;
  wire n139_o;
  wire n140_o;
  wire n142_o;
  wire n143_o;
  wire n146_o;
  wire n147_o;
  wire n148_o;
  wire n149_o;
  wire n151_o;
  wire n152_o;
  wire n153_o;
  wire n155_o;
  wire n157_o;
  wire n158_o;
  wire n160_o;
  wire n161_o;
  wire n164_o;
  wire n165_o;
  wire [6:0] n166_o;
  wire n167_o;
  wire n168_o;
  wire n169_o;
  wire n171_o;
  wire n172_o;
  wire n175_o;
  wire n176_o;
  wire n177_o;
  wire n179_o;
  wire n180_o;
  wire n183_o;
  wire n185_o;
  wire n187_o;
  wire n189_o;
  wire n192_o;
  wire n194_o;
  wire n197_o;
  wire n199_o;
  wire n202_o;
  wire n205_o;
  wire n207_o;
  wire n209_o;
  wire [6:0] n210_o;
  wire [6:0] n211_o;
  wire [6:0] n212_o;
  wire n214_o;
  wire n215_o;
  wire [6:0] n216_o;
  wire [6:0] n217_o;
  wire [6:0] n218_o;
  wire [6:0] n219_o;
  wire [6:0] n220_o;
  wire [6:0] n221_o;
  wire n223_o;
  wire n225_o;
  wire [15:0] n226_o;
  wire [7:0] n227_o;
  reg [7:0] n228_o;
  wire [7:0] n229_o;
  reg [7:0] n230_o;
  wire [7:0] n231_o;
  reg [7:0] n232_o;
  wire [7:0] n233_o;
  reg [7:0] n234_o;
  reg [6:0] n235_o;
  wire n236_o;
  wire n237_o;
  reg n238_o;
  wire n239_o;
  wire n240_o;
  reg n241_o;
  wire n242_o;
  wire n243_o;
  reg n244_o;
  wire n245_o;
  wire n246_o;
  reg n247_o;
  wire n248_o;
  wire n249_o;
  reg n250_o;
  wire n251_o;
  wire n252_o;
  reg n253_o;
  wire n254_o;
  wire n255_o;
  reg n256_o;
  wire [7:0] n257_o;
  reg [7:0] n258_o;
  wire [7:0] n259_o;
  reg [7:0] n260_o;
  wire [7:0] n261_o;
  reg [7:0] n262_o;
  reg [7:0] n263_o;
  reg [7:0] n264_o;
  wire [31:0] n265_o;
  wire [31:0] n266_o;
  wire [6:0] n267_o;
  wire [6:0] n268_o;
  wire [6:0] n269_o;
  wire [15:0] n270_o;
  wire [15:0] n271_o;
  wire [7:0] n272_o;
  wire [7:0] n273_o;
  wire [7:0] n274_o;
  wire [7:0] n275_o;
  wire [7:0] n276_o;
  wire [7:0] n277_o;
  wire [7:0] n278_o;
  wire [7:0] n279_o;
  wire [7:0] n280_o;
  wire [7:0] n281_o;
  wire [7:0] n282_o;
  wire n283_o;
  wire n284_o;
  wire n285_o;
  wire [6:0] n286_o;
  wire n288_o;
  wire n290_o;
  wire [7:0] n291_o;
  wire n293_o;
  wire [7:0] n294_o;
  wire n296_o;
  wire [7:0] n297_o;
  wire n299_o;
  wire [7:0] n300_o;
  wire n302_o;
  wire [7:0] n303_o;
  wire n305_o;
  wire [7:0] n306_o;
  wire n308_o;
  wire [7:0] n309_o;
  wire n311_o;
  wire [7:0] n312_o;
  wire n314_o;
  wire n316_o;
  wire n318_o;
  wire n320_o;
  wire [7:0] n321_o;
  wire n323_o;
  wire [7:0] n325_o;
  wire n327_o;
  wire n329_o;
  wire [15:0] n330_o;
  wire [6:0] n331_o;
  wire [6:0] n332_o;
  wire [6:0] n333_o;
  wire [6:0] n334_o;
  wire [6:0] n335_o;
  wire [6:0] n336_o;
  wire [6:0] n337_o;
  wire [6:0] n338_o;
  wire [6:0] n339_o;
  wire [6:0] n340_o;
  wire [6:0] n341_o;
  wire [6:0] n342_o;
  wire [6:0] n343_o;
  wire [6:0] n344_o;
  wire [6:0] n345_o;
  reg [6:0] n347_o;
  wire n348_o;
  wire n349_o;
  wire n350_o;
  wire n351_o;
  wire n352_o;
  wire n353_o;
  wire n354_o;
  wire n355_o;
  wire n356_o;
  wire n357_o;
  wire n358_o;
  wire n359_o;
  wire n360_o;
  wire n361_o;
  wire n362_o;
  reg n364_o;
  wire n367_o;
  wire n368_o;
  wire n369_o;
  wire n371_o;
  wire n372_o;
  wire n375_o;
  wire n376_o;
  wire n377_o;
  wire n379_o;
  wire n380_o;
  wire n383_o;
  wire n386_o;
  wire n389_o;
  wire n392_o;
  wire [4:0] n393_o;
  wire n394_o;
  reg n395_o;
  wire n396_o;
  reg n397_o;
  wire n398_o;
  reg n399_o;
  wire n400_o;
  reg n401_o;
  wire n402_o;
  reg n403_o;
  wire n404_o;
  reg n405_o;
  wire n406_o;
  reg n407_o;
  wire [6:0] n408_o;
  wire [6:0] n409_o;
  wire [31:0] n411_o;
  wire [6:0] n413_o;
  wire [6:0] n415_o;
  wire [15:0] n417_o;
  wire [7:0] n419_o;
  wire [15:0] n420_o;
  wire [15:0] n421_o;
  wire [7:0] n423_o;
  wire [7:0] n425_o;
  wire n427_o;
  wire n429_o;
  wire n431_o;
  wire n433_o;
  wire n435_o;
  wire n437_o;
  wire n439_o;
  wire n441_o;
  wire n443_o;
  wire n445_o;
  wire n447_o;
  wire n449_o;
  wire n451_o;
  wire n453_o;
  wire n455_o;
  wire n457_o;
  wire [7:0] n458_o;
  wire [7:0] n488_o;
  wire [6:0] n489_o;
  wire n490_o;
  wire n491_o;
  wire n492_o;
  wire n493_o;
  wire [7:0] n494_o;
  wire [6:0] n495_o;
  wire n496_o;
  wire n497_o;
  wire n498_o;
  wire tmr_a_timer_a_reload;
  wire tmr_a_timer_a_toggle;
  wire tmr_a_timer_a_may_interrupt;
  wire [7:0] n502_o;
  wire [7:0] n503_o;
  wire [7:0] n504_o;
  wire n505_o;
  wire n506_o;
  wire n508_o;
  wire n510_o;
  wire [15:0] n512_o;
  wire [15:0] n513_o;
  wire [15:0] n514_o;
  wire n516_o;
  wire n517_o;
  wire [15:0] n518_o;
  wire n519_o;
  wire n520_o;
  wire n521_o;
  wire n522_o;
  wire n523_o;
  wire n524_o;
  wire n525_o;
  wire n526_o;
  wire n527_o;
  wire n528_o;
  wire [7:0] n529_o;
  wire [15:0] n530_o;
  wire [15:0] n531_o;
  wire n533_o;
  wire n534_o;
  wire n536_o;
  wire [15:0] n538_o;
  wire n540_o;
  wire n542_o;
  wire n544_o;
  wire n550_o;
  wire n551_o;
  reg n552_q;
  reg n553_q;
  reg n554_q;
  wire tmr_b_timer_b_reload_lo;
  wire tmr_b_timer_b_oneshot_trig;
  wire tmr_b_timer_b_timeout;
  wire tmr_b_pb6_c;
  wire tmr_b_pb6_d;
  wire n559_o;
  wire n562_o;
  wire n563_o;
  wire n564_o;
  wire n567_o;
  wire n569_o;
  wire n571_o;
  wire n573_o;
  wire n576_o;
  wire n577_o;
  wire n579_o;
  wire [7:0] n580_o;
  wire n582_o;
  wire [2:0] n583_o;
  wire n585_o;
  wire n587_o;
  wire n588_o;
  wire n590_o;
  wire n591_o;
  reg n594_o;
  reg n596_o;
  wire n598_o;
  wire n599_o;
  wire [15:0] n601_o;
  wire [15:0] n602_o;
  wire n604_o;
  wire n606_o;
  wire n607_o;
  wire n609_o;
  wire [7:0] n611_o;
  wire [7:0] n612_o;
  wire [7:0] n613_o;
  wire [7:0] n614_o;
  wire n616_o;
  wire [15:0] n617_o;
  wire [15:0] n618_o;
  wire n620_o;
  wire n621_o;
  wire [7:0] n626_o;
  wire [15:0] n627_o;
  wire [15:0] n628_o;
  wire n630_o;
  wire [15:0] n632_o;
  wire n634_o;
  wire n636_o;
  wire n646_o;
  reg n647_q;
  reg n648_q;
  wire n649_o;
  reg n650_q;
  wire n651_o;
  reg n652_q;
  wire n653_o;
  reg n654_q;
  wire ser_trigger_serial;
  wire ser_shift_clock_d;
  wire ser_shift_clock;
  wire ser_shift_tick_r;
  wire ser_shift_tick_f;
  wire ser_shift_timer_tick;
  wire [2:0] ser_bit_cnt;
  wire ser_shift_pulse;
  wire [1:0] n657_o;
  wire n659_o;
  wire n661_o;
  wire n663_o;
  wire n664_o;
  wire n665_o;
  wire n666_o;
  wire [1:0] n667_o;
  reg n669_o;
  wire n670_o;
  wire [2:0] n671_o;
  wire n673_o;
  wire n674_o;
  wire n675_o;
  wire n677_o;
  wire n678_o;
  wire n683_o;
  wire [2:0] n684_o;
  wire n686_o;
  wire n688_o;
  wire [1:0] n689_o;
  wire n691_o;
  wire n692_o;
  wire n693_o;
  wire n694_o;
  wire n695_o;
  wire n696_o;
  wire n697_o;
  wire n700_o;
  wire n702_o;
  wire [1:0] n708_o;
  wire n710_o;
  wire n711_o;
  wire n712_o;
  wire n713_o;
  wire n714_o;
  wire n715_o;
  wire n716_o;
  wire n717_o;
  wire n719_o;
  wire n721_o;
  wire n722_o;
  wire n723_o;
  wire n725_o;
  wire n726_o;
  wire n727_o;
  wire n728_o;
  wire n733_o;
  wire n734_o;
  wire n735_o;
  wire n736_o;
  wire [6:0] n737_o;
  wire n738_o;
  wire [7:0] n739_o;
  wire n740_o;
  wire n741_o;
  wire n742_o;
  wire [6:0] n743_o;
  wire [7:0] n744_o;
  wire [7:0] n745_o;
  wire [7:0] n746_o;
  wire [7:0] n747_o;
  wire [7:0] n748_o;
  wire [7:0] n750_o;
  wire n753_o;
  wire n754_o;
  wire n755_o;
  wire n756_o;
  wire n760_o;
  wire [2:0] n761_o;
  wire n763_o;
  wire n764_o;
  wire n766_o;
  wire [2:0] n768_o;
  wire [1:0] n769_o;
  wire n771_o;
  wire n772_o;
  wire n773_o;
  wire [31:0] n774_o;
  wire n776_o;
  wire [31:0] n777_o;
  wire [31:0] n779_o;
  wire [2:0] n780_o;
  wire n782_o;
  wire [2:0] n783_o;
  wire n784_o;
  wire [2:0] n785_o;
  wire n786_o;
  wire [2:0] n787_o;
  wire n788_o;
  wire [2:0] n789_o;
  wire n790_o;
  wire [2:0] n791_o;
  wire n793_o;
  wire [2:0] n795_o;
  reg n799_q;
  reg n800_q;
  wire n801_o;
  reg n802_q;
  reg [2:0] n803_q;
  reg [31:0] n804_q;
  reg [7:0] n805_q;
  reg [7:0] n806_q;
  reg [6:0] n807_q;
  reg [6:0] n808_q;
  wire [6:0] n809_o;
  reg [15:0] n810_q;
  reg [15:0] n811_q;
  reg [15:0] n812_q;
  reg [15:0] n813_q;
  wire n814_o;
  reg n815_q;
  reg [7:0] n816_q;
  reg [7:0] n817_q;
  reg [7:0] n818_q;
  wire [7:0] n819_o;
  reg [7:0] n820_q;
  wire [7:0] n821_o;
  reg [7:0] n822_q;
  reg n823_q;
  reg n824_q;
  reg n825_q;
  reg n826_q;
  reg n827_q;
  reg n828_q;
  reg n829_q;
  reg n830_q;
  reg n831_q;
  reg n832_q;
  reg n833_q;
  reg n834_q;
  reg n835_q;
  reg n836_q;
  reg n837_q;
  reg n838_q;
  reg n839_q;
  reg [7:0] n840_q;
  reg n841_q;
  wire [7:0] n842_o;
  wire [7:0] n843_o;
  assign data_out = n840_q; //(module output)
  assign phi2_ref = n841_q; //(module output)
  assign port_a_o = n488_o; //(module output)
  assign port_a_t = n494_o; //(module output)
  assign port_b_o = n842_o; //(module output)
  assign port_b_t = n843_o; //(module output)
  assign ca2_o = n85_o; //(module output)
  assign ca2_t = n68_o; //(module output)
  assign cb1_o = cb1_o_int; //(module output)
  assign cb1_t = cb1_t_int; //(module output)
  assign cb2_o = cb2_o_int; //(module output)
  assign cb2_t = cb2_t_int; //(module output)
  assign irq = irq_out; //(module output)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:77:12  */
  assign pio_i = n804_q; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:78:12  */
  always @*
    port_a_c = n805_q; // (isignal)
  initial
    port_a_c = 8'b00000000;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:79:12  */
  always @*
    port_b_c = n806_q; // (isignal)
  initial
    port_b_c = 8'b00000000;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:81:12  */
  always @*
    irq_mask = n807_q; // (isignal)
  initial
    irq_mask = 7'b0000000;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:82:12  */
  always @*
    irq_flags = n808_q; // (isignal)
  initial
    irq_flags = 7'b0000000;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:83:12  */
  always @*
    irq_events = n809_o; // (isignal)
  initial
    irq_events = 7'b0000000;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:84:12  */
  assign irq_out = n104_o; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:86:12  */
  always @*
    timer_a_latch = n810_q; // (isignal)
  initial
    timer_a_latch = 16'b0101010101010000;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:87:12  */
  always @*
    timer_b_latch = n811_q; // (isignal)
  initial
    timer_b_latch = 16'b0101010101010000;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:88:12  */
  always @*
    timer_a_count = n812_q; // (isignal)
  initial
    timer_a_count = 16'b0101010101010000;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:89:12  */
  always @*
    timer_b_count = n813_q; // (isignal)
  initial
    timer_b_count = 16'b0101010101010000;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:90:12  */
  assign timer_a_out = tmr_a_timer_a_toggle; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:91:12  */
  assign timer_b_tick = n815_q; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:93:12  */
  always @*
    acr = n816_q; // (isignal)
  initial
    acr = 8'b00000000;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:93:17  */
  always @*
    pcr = n817_q; // (isignal)
  initial
    pcr = 8'b00000000;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:94:12  */
  always @*
    shift_reg = n818_q; // (isignal)
  initial
    shift_reg = 8'b00000000;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:95:12  */
  assign serport_en = n717_o; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:96:12  */
  assign ser_cb2_o = n712_o; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:97:12  */
  assign hs_cb2_o = n96_o; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:98:12  */
  assign cb1_t_int = n711_o; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:99:12  */
  assign cb1_o_int = ser_shift_clock_d; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:100:12  */
  assign cb2_t_int = n71_o; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:101:12  */
  assign cb2_o_int = n74_o; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:140:12  */
  always @*
    ira = n820_q; // (isignal)
  initial
    ira = 8'b00000000;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:140:17  */
  always @*
    irb = n822_q; // (isignal)
  initial
    irb = 8'b00000000;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:142:12  */
  assign write_t1c_l = n36_o; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:143:12  */
  assign write_t1c_h = n43_o; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:144:12  */
  assign write_t2c_h = n50_o; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:146:12  */
  assign ca1_c = n823_q; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:146:19  */
  assign ca2_c = n824_q; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:147:12  */
  assign cb1_c = n825_q; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:147:19  */
  assign cb2_c = n826_q; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:148:12  */
  assign ca1_d1 = n827_q; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:148:20  */
  assign ca2_d1 = n828_q; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:149:12  */
  assign cb1_d1 = n829_q; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:149:20  */
  assign cb2_d1 = n830_q; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:150:12  */
  assign ca1_d2 = n831_q; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:150:20  */
  assign ca2_d2 = n832_q; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:151:12  */
  assign cb1_d2 = n833_q; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:151:20  */
  assign cb2_d2 = n834_q; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:153:12  */
  assign ca2_handshake_o = n835_q; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:154:12  */
  assign ca2_pulse_o = n836_q; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:155:12  */
  assign cb2_handshake_o = n837_q; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:156:12  */
  assign cb2_pulse_o = n838_q; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:157:12  */
  assign shift_active = n839_q; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:161:35  */
  assign n30_o = addr == 4'b0100;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:161:50  */
  assign n32_o = addr == 4'b0110;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:161:42  */
  assign n33_o = n30_o | n32_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:161:58  */
  assign n34_o = wen & n33_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:161:70  */
  assign n35_o = falling & n34_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:161:24  */
  assign n36_o = n35_o ? 1'b1 : 1'b0;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:162:34  */
  assign n40_o = addr == 4'b0101;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:162:41  */
  assign n41_o = wen & n40_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:162:53  */
  assign n42_o = falling & n41_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:162:24  */
  assign n43_o = n42_o ? 1'b1 : 1'b0;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:163:34  */
  assign n47_o = addr == 4'b1001;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:163:41  */
  assign n48_o = wen & n47_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:163:53  */
  assign n49_o = falling & n48_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:163:24  */
  assign n50_o = n49_o ? 1'b1 : 1'b0;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:165:26  */
  assign n52_o = ca1_d1 ^ ca1_d2;
  assign n53_o = pcr[0]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:165:50  */
  assign n54_o = ca1_d2 ^ n53_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:165:38  */
  assign n55_o = n52_o & n54_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:166:26  */
  assign n56_o = ca2_d1 ^ ca2_d2;
  assign n57_o = pcr[2]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:166:50  */
  assign n58_o = ca2_d2 ^ n57_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:166:38  */
  assign n59_o = n56_o & n58_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:167:26  */
  assign n60_o = cb1_d1 ^ cb1_d2;
  assign n61_o = pcr[4]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:167:50  */
  assign n62_o = cb1_d2 ^ n61_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:167:38  */
  assign n63_o = n60_o & n62_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:168:26  */
  assign n64_o = cb2_d1 ^ cb2_d2;
  assign n65_o = pcr[6]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:168:50  */
  assign n66_o = cb2_d2 ^ n65_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:168:38  */
  assign n67_o = n64_o & n66_o;
  assign n68_o = pcr[3]; // extract
  assign n69_o = pcr[7]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:171:47  */
  assign n70_o = ~serport_en;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:171:32  */
  assign n71_o = n70_o ? n69_o : n72_o;
  assign n72_o = acr[4]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:172:47  */
  assign n73_o = ~serport_en;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:172:32  */
  assign n74_o = n73_o ? hs_cb2_o : ser_cb2_o;
  assign n75_o = pcr[2:1]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:180:25  */
  assign n77_o = n75_o == 2'b00;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:181:25  */
  assign n79_o = n75_o == 2'b01;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:182:25  */
  assign n82_o = n75_o == 2'b10;
  assign n84_o = {n82_o, n79_o, n77_o};
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:179:5  */
  always @*
    case (n84_o)
      3'b100: n85_o = 1'b0;
      3'b010: n85_o = ca2_pulse_o;
      3'b001: n85_o = ca2_handshake_o;
      default: n85_o = 1'b1;
    endcase
  assign n86_o = pcr[6:5]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:186:25  */
  assign n88_o = n86_o == 2'b00;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:187:25  */
  assign n90_o = n86_o == 2'b01;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:188:25  */
  assign n93_o = n86_o == 2'b10;
  assign n95_o = {n93_o, n90_o, n88_o};
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:185:5  */
  always @*
    case (n95_o)
      3'b100: n96_o = 1'b0;
      3'b010: n96_o = cb2_pulse_o;
      3'b001: n96_o = cb2_handshake_o;
      default: n96_o = 1'b1;
    endcase
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:193:23  */
  assign n99_o = irq_flags & irq_mask;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:193:37  */
  assign n101_o = n99_o == 7'b0000000;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:193:9  */
  assign n104_o = n101_o ? 1'b0 : 1'b1;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:205:13  */
  assign n110_o = falling ? 1'b0 : n841_q;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:203:13  */
  assign n112_o = rising ? 1'b1 : n110_o;
  assign n118_o = acr[0]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:236:28  */
  assign n119_o = ~n118_o;
  assign n120_o = irq_events[1]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:236:54  */
  assign n121_o = ca2_handshake_o & n120_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:236:34  */
  assign n122_o = n119_o | n121_o;
  assign n124_o = acr[1]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:240:28  */
  assign n125_o = ~n124_o;
  assign n126_o = irq_events[4]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:240:54  */
  assign n127_o = cb2_handshake_o & n126_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:240:34  */
  assign n128_o = n125_o | n127_o;
  assign n130_o = irq_events[1]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:247:30  */
  assign n131_o = ren | wen;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:247:53  */
  assign n133_o = addr == 4'b0001;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:247:44  */
  assign n134_o = n133_o & n131_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:247:60  */
  assign n135_o = falling & n134_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:247:13  */
  assign n137_o = n135_o ? 1'b1 : ca2_handshake_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:245:13  */
  assign n139_o = n130_o ? 1'b0 : n137_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:252:31  */
  assign n140_o = ren | wen;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:252:54  */
  assign n142_o = addr == 4'b0001;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:252:45  */
  assign n143_o = n142_o & n140_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:252:17  */
  assign n146_o = n143_o ? 1'b0 : 1'b1;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:251:13  */
  assign n147_o = falling ? n146_o : ca2_pulse_o;
  assign n148_o = irq_events[4]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:262:30  */
  assign n149_o = ren | wen;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:262:53  */
  assign n151_o = addr == 4'b0000;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:262:44  */
  assign n152_o = n151_o & n149_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:262:60  */
  assign n153_o = falling & n152_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:262:13  */
  assign n155_o = n153_o ? 1'b1 : cb2_handshake_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:260:13  */
  assign n157_o = n148_o ? 1'b0 : n155_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:267:31  */
  assign n158_o = ren | wen;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:267:54  */
  assign n160_o = addr == 4'b0000;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:267:45  */
  assign n161_o = n160_o & n158_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:267:17  */
  assign n164_o = n161_o ? 1'b0 : 1'b1;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:266:13  */
  assign n165_o = falling ? n164_o : cb2_pulse_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:275:36  */
  assign n166_o = irq_flags | irq_events;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:278:24  */
  assign n167_o = falling & wen;
  assign n168_o = pcr[5]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:283:38  */
  assign n169_o = ~n168_o;
  assign n171_o = n166_o[3]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:283:21  */
  assign n172_o = n169_o ? 1'b0 : n171_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:281:17  */
  assign n175_o = addr == 4'b0000;
  assign n176_o = pcr[1]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:290:38  */
  assign n177_o = ~n176_o;
  assign n179_o = n166_o[0]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:290:21  */
  assign n180_o = n177_o ? 1'b0 : n179_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:288:17  */
  assign n183_o = addr == 4'b0001;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:295:17  */
  assign n185_o = addr == 4'b0010;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:298:17  */
  assign n187_o = addr == 4'b0011;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:301:17  */
  assign n189_o = addr == 4'b0100;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:304:17  */
  assign n192_o = addr == 4'b0101;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:308:17  */
  assign n194_o = addr == 4'b0110;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:311:17  */
  assign n197_o = addr == 4'b0111;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:315:17  */
  assign n199_o = addr == 4'b1000;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:318:17  */
  assign n202_o = addr == 4'b1001;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:321:17  */
  assign n205_o = addr == 4'b1010;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:324:17  */
  assign n207_o = addr == 4'b1011;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:327:17  */
  assign n209_o = addr == 4'b1100;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:331:59  */
  assign n210_o = data_in[6:0]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:331:48  */
  assign n211_o = ~n210_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:331:44  */
  assign n212_o = irq_flags & n211_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:330:17  */
  assign n214_o = addr == 4'b1101;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:334:31  */
  assign n215_o = data_in[7]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:335:56  */
  assign n216_o = data_in[6:0]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:335:46  */
  assign n217_o = irq_mask | n216_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:337:61  */
  assign n218_o = data_in[6:0]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:337:50  */
  assign n219_o = ~n218_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:337:46  */
  assign n220_o = irq_mask & n219_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:334:21  */
  assign n221_o = n215_o ? n217_o : n220_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:333:17  */
  assign n223_o = addr == 4'b1110;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:340:17  */
  assign n225_o = addr == 4'b1111;
  assign n226_o = {n225_o, n223_o, n214_o, n209_o, n207_o, n205_o, n202_o, n199_o, n197_o, n194_o, n192_o, n189_o, n187_o, n185_o, n183_o, n175_o};
  assign n227_o = pio_i[7:0]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:280:17  */
  always @*
    case (n226_o)
      16'b1000000000000000: n228_o = data_in;
      16'b0100000000000000: n228_o = n227_o;
      16'b0010000000000000: n228_o = n227_o;
      16'b0001000000000000: n228_o = n227_o;
      16'b0000100000000000: n228_o = n227_o;
      16'b0000010000000000: n228_o = n227_o;
      16'b0000001000000000: n228_o = n227_o;
      16'b0000000100000000: n228_o = n227_o;
      16'b0000000010000000: n228_o = n227_o;
      16'b0000000001000000: n228_o = n227_o;
      16'b0000000000100000: n228_o = n227_o;
      16'b0000000000010000: n228_o = n227_o;
      16'b0000000000001000: n228_o = n227_o;
      16'b0000000000000100: n228_o = n227_o;
      16'b0000000000000010: n228_o = data_in;
      16'b0000000000000001: n228_o = n227_o;
      default: n228_o = n227_o;
    endcase
  assign n229_o = pio_i[15:8]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:280:17  */
  always @*
    case (n226_o)
      16'b1000000000000000: n230_o = n229_o;
      16'b0100000000000000: n230_o = n229_o;
      16'b0010000000000000: n230_o = n229_o;
      16'b0001000000000000: n230_o = n229_o;
      16'b0000100000000000: n230_o = n229_o;
      16'b0000010000000000: n230_o = n229_o;
      16'b0000001000000000: n230_o = n229_o;
      16'b0000000100000000: n230_o = n229_o;
      16'b0000000010000000: n230_o = n229_o;
      16'b0000000001000000: n230_o = n229_o;
      16'b0000000000100000: n230_o = n229_o;
      16'b0000000000010000: n230_o = n229_o;
      16'b0000000000001000: n230_o = data_in;
      16'b0000000000000100: n230_o = n229_o;
      16'b0000000000000010: n230_o = n229_o;
      16'b0000000000000001: n230_o = n229_o;
      default: n230_o = n229_o;
    endcase
  assign n231_o = pio_i[23:16]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:280:17  */
  always @*
    case (n226_o)
      16'b1000000000000000: n232_o = n231_o;
      16'b0100000000000000: n232_o = n231_o;
      16'b0010000000000000: n232_o = n231_o;
      16'b0001000000000000: n232_o = n231_o;
      16'b0000100000000000: n232_o = n231_o;
      16'b0000010000000000: n232_o = n231_o;
      16'b0000001000000000: n232_o = n231_o;
      16'b0000000100000000: n232_o = n231_o;
      16'b0000000010000000: n232_o = n231_o;
      16'b0000000001000000: n232_o = n231_o;
      16'b0000000000100000: n232_o = n231_o;
      16'b0000000000010000: n232_o = n231_o;
      16'b0000000000001000: n232_o = n231_o;
      16'b0000000000000100: n232_o = n231_o;
      16'b0000000000000010: n232_o = n231_o;
      16'b0000000000000001: n232_o = data_in;
      default: n232_o = n231_o;
    endcase
  assign n233_o = pio_i[31:24]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:280:17  */
  always @*
    case (n226_o)
      16'b1000000000000000: n234_o = n233_o;
      16'b0100000000000000: n234_o = n233_o;
      16'b0010000000000000: n234_o = n233_o;
      16'b0001000000000000: n234_o = n233_o;
      16'b0000100000000000: n234_o = n233_o;
      16'b0000010000000000: n234_o = n233_o;
      16'b0000001000000000: n234_o = n233_o;
      16'b0000000100000000: n234_o = n233_o;
      16'b0000000010000000: n234_o = n233_o;
      16'b0000000001000000: n234_o = n233_o;
      16'b0000000000100000: n234_o = n233_o;
      16'b0000000000010000: n234_o = n233_o;
      16'b0000000000001000: n234_o = n233_o;
      16'b0000000000000100: n234_o = data_in;
      16'b0000000000000010: n234_o = n233_o;
      16'b0000000000000001: n234_o = n233_o;
      default: n234_o = n233_o;
    endcase
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:280:17  */
  always @*
    case (n226_o)
      16'b1000000000000000: n235_o = irq_mask;
      16'b0100000000000000: n235_o = n221_o;
      16'b0010000000000000: n235_o = irq_mask;
      16'b0001000000000000: n235_o = irq_mask;
      16'b0000100000000000: n235_o = irq_mask;
      16'b0000010000000000: n235_o = irq_mask;
      16'b0000001000000000: n235_o = irq_mask;
      16'b0000000100000000: n235_o = irq_mask;
      16'b0000000010000000: n235_o = irq_mask;
      16'b0000000001000000: n235_o = irq_mask;
      16'b0000000000100000: n235_o = irq_mask;
      16'b0000000000010000: n235_o = irq_mask;
      16'b0000000000001000: n235_o = irq_mask;
      16'b0000000000000100: n235_o = irq_mask;
      16'b0000000000000010: n235_o = irq_mask;
      16'b0000000000000001: n235_o = irq_mask;
      default: n235_o = irq_mask;
    endcase
  assign n236_o = n212_o[0]; // extract
  assign n237_o = n166_o[0]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:280:17  */
  always @*
    case (n226_o)
      16'b1000000000000000: n238_o = n237_o;
      16'b0100000000000000: n238_o = n237_o;
      16'b0010000000000000: n238_o = n236_o;
      16'b0001000000000000: n238_o = n237_o;
      16'b0000100000000000: n238_o = n237_o;
      16'b0000010000000000: n238_o = n237_o;
      16'b0000001000000000: n238_o = n237_o;
      16'b0000000100000000: n238_o = n237_o;
      16'b0000000010000000: n238_o = n237_o;
      16'b0000000001000000: n238_o = n237_o;
      16'b0000000000100000: n238_o = n237_o;
      16'b0000000000010000: n238_o = n237_o;
      16'b0000000000001000: n238_o = n237_o;
      16'b0000000000000100: n238_o = n237_o;
      16'b0000000000000010: n238_o = n180_o;
      16'b0000000000000001: n238_o = n237_o;
      default: n238_o = n237_o;
    endcase
  assign n239_o = n212_o[1]; // extract
  assign n240_o = n166_o[1]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:280:17  */
  always @*
    case (n226_o)
      16'b1000000000000000: n241_o = n240_o;
      16'b0100000000000000: n241_o = n240_o;
      16'b0010000000000000: n241_o = n239_o;
      16'b0001000000000000: n241_o = n240_o;
      16'b0000100000000000: n241_o = n240_o;
      16'b0000010000000000: n241_o = n240_o;
      16'b0000001000000000: n241_o = n240_o;
      16'b0000000100000000: n241_o = n240_o;
      16'b0000000010000000: n241_o = n240_o;
      16'b0000000001000000: n241_o = n240_o;
      16'b0000000000100000: n241_o = n240_o;
      16'b0000000000010000: n241_o = n240_o;
      16'b0000000000001000: n241_o = n240_o;
      16'b0000000000000100: n241_o = n240_o;
      16'b0000000000000010: n241_o = 1'b0;
      16'b0000000000000001: n241_o = n240_o;
      default: n241_o = n240_o;
    endcase
  assign n242_o = n212_o[2]; // extract
  assign n243_o = n166_o[2]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:280:17  */
  always @*
    case (n226_o)
      16'b1000000000000000: n244_o = n243_o;
      16'b0100000000000000: n244_o = n243_o;
      16'b0010000000000000: n244_o = n242_o;
      16'b0001000000000000: n244_o = n243_o;
      16'b0000100000000000: n244_o = n243_o;
      16'b0000010000000000: n244_o = 1'b0;
      16'b0000001000000000: n244_o = n243_o;
      16'b0000000100000000: n244_o = n243_o;
      16'b0000000010000000: n244_o = n243_o;
      16'b0000000001000000: n244_o = n243_o;
      16'b0000000000100000: n244_o = n243_o;
      16'b0000000000010000: n244_o = n243_o;
      16'b0000000000001000: n244_o = n243_o;
      16'b0000000000000100: n244_o = n243_o;
      16'b0000000000000010: n244_o = n243_o;
      16'b0000000000000001: n244_o = n243_o;
      default: n244_o = n243_o;
    endcase
  assign n245_o = n212_o[3]; // extract
  assign n246_o = n166_o[3]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:280:17  */
  always @*
    case (n226_o)
      16'b1000000000000000: n247_o = n246_o;
      16'b0100000000000000: n247_o = n246_o;
      16'b0010000000000000: n247_o = n245_o;
      16'b0001000000000000: n247_o = n246_o;
      16'b0000100000000000: n247_o = n246_o;
      16'b0000010000000000: n247_o = n246_o;
      16'b0000001000000000: n247_o = n246_o;
      16'b0000000100000000: n247_o = n246_o;
      16'b0000000010000000: n247_o = n246_o;
      16'b0000000001000000: n247_o = n246_o;
      16'b0000000000100000: n247_o = n246_o;
      16'b0000000000010000: n247_o = n246_o;
      16'b0000000000001000: n247_o = n246_o;
      16'b0000000000000100: n247_o = n246_o;
      16'b0000000000000010: n247_o = n246_o;
      16'b0000000000000001: n247_o = n172_o;
      default: n247_o = n246_o;
    endcase
  assign n248_o = n212_o[4]; // extract
  assign n249_o = n166_o[4]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:280:17  */
  always @*
    case (n226_o)
      16'b1000000000000000: n250_o = n249_o;
      16'b0100000000000000: n250_o = n249_o;
      16'b0010000000000000: n250_o = n248_o;
      16'b0001000000000000: n250_o = n249_o;
      16'b0000100000000000: n250_o = n249_o;
      16'b0000010000000000: n250_o = n249_o;
      16'b0000001000000000: n250_o = n249_o;
      16'b0000000100000000: n250_o = n249_o;
      16'b0000000010000000: n250_o = n249_o;
      16'b0000000001000000: n250_o = n249_o;
      16'b0000000000100000: n250_o = n249_o;
      16'b0000000000010000: n250_o = n249_o;
      16'b0000000000001000: n250_o = n249_o;
      16'b0000000000000100: n250_o = n249_o;
      16'b0000000000000010: n250_o = n249_o;
      16'b0000000000000001: n250_o = 1'b0;
      default: n250_o = n249_o;
    endcase
  assign n251_o = n212_o[5]; // extract
  assign n252_o = n166_o[5]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:280:17  */
  always @*
    case (n226_o)
      16'b1000000000000000: n253_o = n252_o;
      16'b0100000000000000: n253_o = n252_o;
      16'b0010000000000000: n253_o = n251_o;
      16'b0001000000000000: n253_o = n252_o;
      16'b0000100000000000: n253_o = n252_o;
      16'b0000010000000000: n253_o = n252_o;
      16'b0000001000000000: n253_o = 1'b0;
      16'b0000000100000000: n253_o = n252_o;
      16'b0000000010000000: n253_o = n252_o;
      16'b0000000001000000: n253_o = n252_o;
      16'b0000000000100000: n253_o = n252_o;
      16'b0000000000010000: n253_o = n252_o;
      16'b0000000000001000: n253_o = n252_o;
      16'b0000000000000100: n253_o = n252_o;
      16'b0000000000000010: n253_o = n252_o;
      16'b0000000000000001: n253_o = n252_o;
      default: n253_o = n252_o;
    endcase
  assign n254_o = n212_o[6]; // extract
  assign n255_o = n166_o[6]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:280:17  */
  always @*
    case (n226_o)
      16'b1000000000000000: n256_o = n255_o;
      16'b0100000000000000: n256_o = n255_o;
      16'b0010000000000000: n256_o = n254_o;
      16'b0001000000000000: n256_o = n255_o;
      16'b0000100000000000: n256_o = n255_o;
      16'b0000010000000000: n256_o = n255_o;
      16'b0000001000000000: n256_o = n255_o;
      16'b0000000100000000: n256_o = n255_o;
      16'b0000000010000000: n256_o = 1'b0;
      16'b0000000001000000: n256_o = n255_o;
      16'b0000000000100000: n256_o = 1'b0;
      16'b0000000000010000: n256_o = n255_o;
      16'b0000000000001000: n256_o = n255_o;
      16'b0000000000000100: n256_o = n255_o;
      16'b0000000000000010: n256_o = n255_o;
      16'b0000000000000001: n256_o = n255_o;
      default: n256_o = n255_o;
    endcase
  assign n257_o = timer_a_latch[7:0]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:280:17  */
  always @*
    case (n226_o)
      16'b1000000000000000: n258_o = n257_o;
      16'b0100000000000000: n258_o = n257_o;
      16'b0010000000000000: n258_o = n257_o;
      16'b0001000000000000: n258_o = n257_o;
      16'b0000100000000000: n258_o = n257_o;
      16'b0000010000000000: n258_o = n257_o;
      16'b0000001000000000: n258_o = n257_o;
      16'b0000000100000000: n258_o = n257_o;
      16'b0000000010000000: n258_o = n257_o;
      16'b0000000001000000: n258_o = data_in;
      16'b0000000000100000: n258_o = n257_o;
      16'b0000000000010000: n258_o = data_in;
      16'b0000000000001000: n258_o = n257_o;
      16'b0000000000000100: n258_o = n257_o;
      16'b0000000000000010: n258_o = n257_o;
      16'b0000000000000001: n258_o = n257_o;
      default: n258_o = n257_o;
    endcase
  assign n259_o = timer_a_latch[15:8]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:280:17  */
  always @*
    case (n226_o)
      16'b1000000000000000: n260_o = n259_o;
      16'b0100000000000000: n260_o = n259_o;
      16'b0010000000000000: n260_o = n259_o;
      16'b0001000000000000: n260_o = n259_o;
      16'b0000100000000000: n260_o = n259_o;
      16'b0000010000000000: n260_o = n259_o;
      16'b0000001000000000: n260_o = n259_o;
      16'b0000000100000000: n260_o = n259_o;
      16'b0000000010000000: n260_o = data_in;
      16'b0000000001000000: n260_o = n259_o;
      16'b0000000000100000: n260_o = data_in;
      16'b0000000000010000: n260_o = n259_o;
      16'b0000000000001000: n260_o = n259_o;
      16'b0000000000000100: n260_o = n259_o;
      16'b0000000000000010: n260_o = n259_o;
      16'b0000000000000001: n260_o = n259_o;
      default: n260_o = n259_o;
    endcase
  assign n261_o = timer_b_latch[7:0]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:280:17  */
  always @*
    case (n226_o)
      16'b1000000000000000: n262_o = n261_o;
      16'b0100000000000000: n262_o = n261_o;
      16'b0010000000000000: n262_o = n261_o;
      16'b0001000000000000: n262_o = n261_o;
      16'b0000100000000000: n262_o = n261_o;
      16'b0000010000000000: n262_o = n261_o;
      16'b0000001000000000: n262_o = n261_o;
      16'b0000000100000000: n262_o = data_in;
      16'b0000000010000000: n262_o = n261_o;
      16'b0000000001000000: n262_o = n261_o;
      16'b0000000000100000: n262_o = n261_o;
      16'b0000000000010000: n262_o = n261_o;
      16'b0000000000001000: n262_o = n261_o;
      16'b0000000000000100: n262_o = n261_o;
      16'b0000000000000010: n262_o = n261_o;
      16'b0000000000000001: n262_o = n261_o;
      default: n262_o = n261_o;
    endcase
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:280:17  */
  always @*
    case (n226_o)
      16'b1000000000000000: n263_o = acr;
      16'b0100000000000000: n263_o = acr;
      16'b0010000000000000: n263_o = acr;
      16'b0001000000000000: n263_o = acr;
      16'b0000100000000000: n263_o = data_in;
      16'b0000010000000000: n263_o = acr;
      16'b0000001000000000: n263_o = acr;
      16'b0000000100000000: n263_o = acr;
      16'b0000000010000000: n263_o = acr;
      16'b0000000001000000: n263_o = acr;
      16'b0000000000100000: n263_o = acr;
      16'b0000000000010000: n263_o = acr;
      16'b0000000000001000: n263_o = acr;
      16'b0000000000000100: n263_o = acr;
      16'b0000000000000010: n263_o = acr;
      16'b0000000000000001: n263_o = acr;
      default: n263_o = acr;
    endcase
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:280:17  */
  always @*
    case (n226_o)
      16'b1000000000000000: n264_o = pcr;
      16'b0100000000000000: n264_o = pcr;
      16'b0010000000000000: n264_o = pcr;
      16'b0001000000000000: n264_o = data_in;
      16'b0000100000000000: n264_o = pcr;
      16'b0000010000000000: n264_o = pcr;
      16'b0000001000000000: n264_o = pcr;
      16'b0000000100000000: n264_o = pcr;
      16'b0000000010000000: n264_o = pcr;
      16'b0000000001000000: n264_o = pcr;
      16'b0000000000100000: n264_o = pcr;
      16'b0000000000010000: n264_o = pcr;
      16'b0000000000001000: n264_o = pcr;
      16'b0000000000000100: n264_o = pcr;
      16'b0000000000000010: n264_o = pcr;
      16'b0000000000000001: n264_o = pcr;
      default: n264_o = pcr;
    endcase
  assign n265_o = {n234_o, n232_o, n230_o, n228_o};
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:278:13  */
  assign n266_o = n167_o ? n265_o : pio_i;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:278:13  */
  assign n267_o = n167_o ? n235_o : irq_mask;
  assign n268_o = {n256_o, n253_o, n250_o, n247_o, n244_o, n241_o, n238_o};
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:278:13  */
  assign n269_o = n167_o ? n268_o : n166_o;
  assign n270_o = {n260_o, n258_o};
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:278:13  */
  assign n271_o = n167_o ? n270_o : timer_a_latch;
  assign n272_o = timer_b_latch[7:0]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:278:13  */
  assign n273_o = n167_o ? n262_o : n272_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:278:13  */
  assign n274_o = n167_o ? n263_o : acr;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:278:13  */
  assign n275_o = n167_o ? n264_o : pcr;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:353:36  */
  assign n276_o = pio_i[23:16]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:353:50  */
  assign n277_o = pio_i[31:24]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:353:40  */
  assign n278_o = n276_o & n277_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:353:78  */
  assign n279_o = pio_i[31:24]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:353:68  */
  assign n280_o = ~n279_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:353:64  */
  assign n281_o = irb & n280_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:353:56  */
  assign n282_o = n278_o | n281_o;
  assign n283_o = acr[7]; // extract
  assign n284_o = n282_o[7]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:354:17  */
  assign n285_o = n283_o ? timer_a_out : n284_o;
  assign n286_o = n282_o[6:0]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:351:13  */
  assign n288_o = addr == 4'b0000;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:357:13  */
  assign n290_o = addr == 4'b0001;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:360:35  */
  assign n291_o = pio_i[31:24]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:359:13  */
  assign n293_o = addr == 4'b0010;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:362:35  */
  assign n294_o = pio_i[15:8]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:361:13  */
  assign n296_o = addr == 4'b0011;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:364:42  */
  assign n297_o = timer_a_count[7:0]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:363:13  */
  assign n299_o = addr == 4'b0100;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:366:42  */
  assign n300_o = timer_a_count[15:8]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:365:13  */
  assign n302_o = addr == 4'b0101;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:368:42  */
  assign n303_o = timer_a_latch[7:0]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:367:13  */
  assign n305_o = addr == 4'b0110;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:370:42  */
  assign n306_o = timer_a_latch[15:8]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:369:13  */
  assign n308_o = addr == 4'b0111;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:372:42  */
  assign n309_o = timer_b_count[7:0]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:371:13  */
  assign n311_o = addr == 4'b1000;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:374:42  */
  assign n312_o = timer_b_count[15:8]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:373:13  */
  assign n314_o = addr == 4'b1001;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:375:13  */
  assign n316_o = addr == 4'b1010;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:377:13  */
  assign n318_o = addr == 4'b1011;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:379:13  */
  assign n320_o = addr == 4'b1100;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:382:38  */
  assign n321_o = {irq_out, irq_flags};
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:381:13  */
  assign n323_o = addr == 4'b1101;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:384:34  */
  assign n325_o = {1'b0, irq_mask};
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:383:13  */
  assign n327_o = addr == 4'b1110;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:385:13  */
  assign n329_o = addr == 4'b1111;
  assign n330_o = {n329_o, n327_o, n323_o, n320_o, n318_o, n316_o, n314_o, n311_o, n308_o, n305_o, n302_o, n299_o, n296_o, n293_o, n290_o, n288_o};
  assign n331_o = ira[6:0]; // extract
  assign n332_o = n291_o[6:0]; // extract
  assign n333_o = n294_o[6:0]; // extract
  assign n334_o = n297_o[6:0]; // extract
  assign n335_o = n300_o[6:0]; // extract
  assign n336_o = n303_o[6:0]; // extract
  assign n337_o = n306_o[6:0]; // extract
  assign n338_o = n309_o[6:0]; // extract
  assign n339_o = n312_o[6:0]; // extract
  assign n340_o = shift_reg[6:0]; // extract
  assign n341_o = acr[6:0]; // extract
  assign n342_o = pcr[6:0]; // extract
  assign n343_o = n321_o[6:0]; // extract
  assign n344_o = n325_o[6:0]; // extract
  assign n345_o = ira[6:0]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:350:13  */
  always @*
    case (n330_o)
      16'b1000000000000000: n347_o = n345_o;
      16'b0100000000000000: n347_o = n344_o;
      16'b0010000000000000: n347_o = n343_o;
      16'b0001000000000000: n347_o = n342_o;
      16'b0000100000000000: n347_o = n341_o;
      16'b0000010000000000: n347_o = n340_o;
      16'b0000001000000000: n347_o = n339_o;
      16'b0000000100000000: n347_o = n338_o;
      16'b0000000010000000: n347_o = n337_o;
      16'b0000000001000000: n347_o = n336_o;
      16'b0000000000100000: n347_o = n335_o;
      16'b0000000000010000: n347_o = n334_o;
      16'b0000000000001000: n347_o = n333_o;
      16'b0000000000000100: n347_o = n332_o;
      16'b0000000000000010: n347_o = n331_o;
      16'b0000000000000001: n347_o = n286_o;
      default: n347_o = 7'b0000000;
    endcase
  assign n348_o = ira[7]; // extract
  assign n349_o = n291_o[7]; // extract
  assign n350_o = n294_o[7]; // extract
  assign n351_o = n297_o[7]; // extract
  assign n352_o = n300_o[7]; // extract
  assign n353_o = n303_o[7]; // extract
  assign n354_o = n306_o[7]; // extract
  assign n355_o = n309_o[7]; // extract
  assign n356_o = n312_o[7]; // extract
  assign n357_o = shift_reg[7]; // extract
  assign n358_o = acr[7]; // extract
  assign n359_o = pcr[7]; // extract
  assign n360_o = n321_o[7]; // extract
  assign n361_o = n325_o[7]; // extract
  assign n362_o = ira[7]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:350:13  */
  always @*
    case (n330_o)
      16'b1000000000000000: n364_o = n362_o;
      16'b0100000000000000: n364_o = n361_o;
      16'b0010000000000000: n364_o = n360_o;
      16'b0001000000000000: n364_o = n359_o;
      16'b0000100000000000: n364_o = n358_o;
      16'b0000010000000000: n364_o = n357_o;
      16'b0000001000000000: n364_o = n356_o;
      16'b0000000100000000: n364_o = n355_o;
      16'b0000000010000000: n364_o = n354_o;
      16'b0000000001000000: n364_o = n353_o;
      16'b0000000000100000: n364_o = n352_o;
      16'b0000000000010000: n364_o = n351_o;
      16'b0000000000001000: n364_o = n350_o;
      16'b0000000000000100: n364_o = n349_o;
      16'b0000000000000010: n364_o = n348_o;
      16'b0000000000000001: n364_o = n285_o;
      default: n364_o = 1'b0;
    endcase
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:392:26  */
  assign n367_o = falling & ren;
  assign n368_o = pcr[5]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:395:38  */
  assign n369_o = ~n368_o;
  assign n371_o = n269_o[3]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:395:21  */
  assign n372_o = n369_o ? 1'b0 : n371_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:394:17  */
  assign n375_o = addr == 4'b0000;
  assign n376_o = pcr[1]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:401:38  */
  assign n377_o = ~n376_o;
  assign n379_o = n269_o[0]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:401:21  */
  assign n380_o = n377_o ? 1'b0 : n379_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:400:17  */
  assign n383_o = addr == 4'b0001;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:406:17  */
  assign n386_o = addr == 4'b0100;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:409:17  */
  assign n389_o = addr == 4'b1000;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:412:17  */
  assign n392_o = addr == 4'b1010;
  assign n393_o = {n392_o, n389_o, n386_o, n383_o, n375_o};
  assign n394_o = n269_o[0]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:393:17  */
  always @*
    case (n393_o)
      5'b10000: n395_o = n394_o;
      5'b01000: n395_o = n394_o;
      5'b00100: n395_o = n394_o;
      5'b00010: n395_o = n380_o;
      5'b00001: n395_o = n394_o;
      default: n395_o = n394_o;
    endcase
  assign n396_o = n269_o[1]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:393:17  */
  always @*
    case (n393_o)
      5'b10000: n397_o = n396_o;
      5'b01000: n397_o = n396_o;
      5'b00100: n397_o = n396_o;
      5'b00010: n397_o = 1'b0;
      5'b00001: n397_o = n396_o;
      default: n397_o = n396_o;
    endcase
  assign n398_o = n269_o[2]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:393:17  */
  always @*
    case (n393_o)
      5'b10000: n399_o = 1'b0;
      5'b01000: n399_o = n398_o;
      5'b00100: n399_o = n398_o;
      5'b00010: n399_o = n398_o;
      5'b00001: n399_o = n398_o;
      default: n399_o = n398_o;
    endcase
  assign n400_o = n269_o[3]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:393:17  */
  always @*
    case (n393_o)
      5'b10000: n401_o = n400_o;
      5'b01000: n401_o = n400_o;
      5'b00100: n401_o = n400_o;
      5'b00010: n401_o = n400_o;
      5'b00001: n401_o = n372_o;
      default: n401_o = n400_o;
    endcase
  assign n402_o = n269_o[4]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:393:17  */
  always @*
    case (n393_o)
      5'b10000: n403_o = n402_o;
      5'b01000: n403_o = n402_o;
      5'b00100: n403_o = n402_o;
      5'b00010: n403_o = n402_o;
      5'b00001: n403_o = 1'b0;
      default: n403_o = n402_o;
    endcase
  assign n404_o = n269_o[5]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:393:17  */
  always @*
    case (n393_o)
      5'b10000: n405_o = n404_o;
      5'b01000: n405_o = 1'b0;
      5'b00100: n405_o = n404_o;
      5'b00010: n405_o = n404_o;
      5'b00001: n405_o = n404_o;
      default: n405_o = n404_o;
    endcase
  assign n406_o = n269_o[6]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:393:17  */
  always @*
    case (n393_o)
      5'b10000: n407_o = n406_o;
      5'b01000: n407_o = n406_o;
      5'b00100: n407_o = 1'b0;
      5'b00010: n407_o = n406_o;
      5'b00001: n407_o = n406_o;
      default: n407_o = n406_o;
    endcase
  assign n408_o = {n407_o, n405_o, n403_o, n401_o, n399_o, n397_o, n395_o};
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:392:13  */
  assign n409_o = n367_o ? n408_o : n269_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:420:13  */
  assign n411_o = reset ? 32'b00000000000000000000000000000000 : n266_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:420:13  */
  assign n413_o = reset ? 7'b0000000 : n267_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:420:13  */
  assign n415_o = reset ? 7'b0000000 : n409_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:420:13  */
  assign n417_o = reset ? 16'b0101010101010000 : n271_o;
  assign n419_o = timer_b_latch[15:8]; // extract
  assign n420_o = {n419_o, n273_o};
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:420:13  */
  assign n421_o = reset ? 16'b0101010101010000 : n420_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:420:13  */
  assign n423_o = reset ? 8'b00000000 : n274_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:420:13  */
  assign n425_o = reset ? 8'b00000000 : n275_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:420:13  */
  assign n427_o = reset ? 1'b1 : ca1_i;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:420:13  */
  assign n429_o = reset ? 1'b1 : ca2_i;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:420:13  */
  assign n431_o = reset ? 1'b1 : cb1_i;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:420:13  */
  assign n433_o = reset ? 1'b1 : cb2_i;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:420:13  */
  assign n435_o = reset ? 1'b1 : ca1_c;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:420:13  */
  assign n437_o = reset ? 1'b1 : ca2_c;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:420:13  */
  assign n439_o = reset ? 1'b1 : cb1_c;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:420:13  */
  assign n441_o = reset ? 1'b1 : cb2_c;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:420:13  */
  assign n443_o = reset ? 1'b1 : ca1_d1;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:420:13  */
  assign n445_o = reset ? 1'b1 : ca2_d1;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:420:13  */
  assign n447_o = reset ? 1'b1 : cb1_d1;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:420:13  */
  assign n449_o = reset ? 1'b1 : cb2_d1;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:420:13  */
  assign n451_o = reset ? 1'b1 : n139_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:420:13  */
  assign n453_o = reset ? 1'b1 : n147_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:420:13  */
  assign n455_o = reset ? 1'b1 : n157_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:420:13  */
  assign n457_o = reset ? 1'b1 : n165_o;
  assign n458_o = {n364_o, n347_o};
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:451:35  */
  assign n488_o = pio_i[7:0]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:452:38  */
  assign n489_o = pio_i[22:16]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:453:29  */
  assign n490_o = pio_i[23]; // extract
  assign n491_o = acr[7]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:453:53  */
  assign n492_o = ~n491_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:453:33  */
  assign n493_o = n492_o ? n490_o : timer_a_out;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:455:35  */
  assign n494_o = pio_i[15:8]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:456:39  */
  assign n495_o = pio_i[30:24]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:457:39  */
  assign n496_o = pio_i[31]; // extract
  assign n497_o = acr[7]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:457:43  */
  assign n498_o = n496_o | n497_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:462:16  */
  assign tmr_a_timer_a_reload = n552_q; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:463:16  */
  assign tmr_a_timer_a_toggle = n553_q; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:464:16  */
  assign tmr_a_timer_a_may_interrupt = n554_q; // (signal)
  assign n502_o = timer_a_latch[7:0]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:474:25  */
  assign n503_o = write_t1c_l ? data_in : n502_o;
  assign n504_o = timer_a_latch[15:8]; // extract
  assign n505_o = acr[6]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:478:72  */
  assign n506_o = tmr_a_timer_a_may_interrupt & n505_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:480:42  */
  assign n508_o = timer_a_count == 16'b0000000000000000;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:480:25  */
  assign n510_o = n508_o ? 1'b1 : tmr_a_timer_a_reload;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:485:56  */
  assign n512_o = timer_a_count - 16'b0000000000000001;
  assign n513_o = {n504_o, n503_o};
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:472:21  */
  assign n514_o = tmr_a_timer_a_reload ? n513_o : n512_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:472:21  */
  assign n516_o = tmr_a_timer_a_reload ? 1'b0 : n510_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:469:17  */
  assign n517_o = n520_o ? n506_o : tmr_a_timer_a_may_interrupt;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:469:17  */
  assign n518_o = falling ? n514_o : timer_a_count;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:469:17  */
  assign n519_o = falling ? n516_o : tmr_a_timer_a_reload;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:469:17  */
  assign n520_o = tmr_a_timer_a_reload & falling;
  assign n521_o = irq_events[6]; // extract
  assign n522_o = acr[7]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:490:44  */
  assign n523_o = n522_o & n521_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:491:43  */
  assign n524_o = ~tmr_a_timer_a_toggle;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:489:17  */
  assign n525_o = n526_o ? n524_o : tmr_a_timer_a_toggle;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:489:17  */
  assign n526_o = n523_o & rising;
  assign n527_o = acr[7]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:497:39  */
  assign n528_o = ~n527_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:498:62  */
  assign n529_o = timer_a_latch[7:0]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:498:47  */
  assign n530_o = {data_in, n529_o};
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:495:17  */
  assign n531_o = write_t1c_h ? n530_o : n518_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:495:17  */
  assign n533_o = write_t1c_h ? 1'b0 : n519_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:495:17  */
  assign n534_o = write_t1c_h ? n528_o : n525_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:495:17  */
  assign n536_o = write_t1c_h ? 1'b1 : n517_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:502:17  */
  assign n538_o = reset ? 16'b0101010101010000 : n531_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:502:17  */
  assign n540_o = reset ? 1'b0 : n533_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:502:17  */
  assign n542_o = reset ? 1'b1 : n534_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:502:17  */
  assign n544_o = reset ? 1'b0 : n536_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:512:33  */
  assign n550_o = rising & tmr_a_timer_a_reload;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:512:52  */
  assign n551_o = n550_o & tmr_a_timer_a_may_interrupt;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:468:13  */
  always @(posedge clock)
    n552_q <= n540_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:468:13  */
  always @(posedge clock)
    n553_q <= n542_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:468:13  */
  always @(posedge clock)
    n554_q <= n544_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:518:16  */
  assign tmr_b_timer_b_reload_lo = n647_q; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:519:16  */
  assign tmr_b_timer_b_oneshot_trig = n648_q; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:520:16  */
  assign tmr_b_timer_b_timeout = n650_q; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:521:16  */
  assign tmr_b_pb6_c = n652_q; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:521:23  */
  assign tmr_b_pb6_d = n654_q; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:530:45  */
  assign n559_o = port_b_i[6]; // extract
  assign n562_o = acr[5]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:539:48  */
  assign n563_o = ~tmr_b_pb6_c;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:539:39  */
  assign n564_o = n563_o & tmr_b_pb6_d;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:539:25  */
  assign n567_o = n564_o ? 1'b1 : 1'b0;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:538:21  */
  assign n569_o = n562_o ? n567_o : 1'b1;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:547:42  */
  assign n571_o = timer_b_count == 16'b0000000000000000;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:534:17  */
  assign n573_o = n621_o ? 1'b0 : tmr_b_timer_b_oneshot_trig;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:548:29  */
  assign n576_o = tmr_b_timer_b_oneshot_trig ? 1'b1 : 1'b0;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:547:25  */
  assign n577_o = tmr_b_timer_b_oneshot_trig & n571_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:547:25  */
  assign n579_o = n571_o ? n576_o : 1'b0;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:553:41  */
  assign n580_o = timer_b_count[7:0]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:553:54  */
  assign n582_o = n580_o == 8'b00000000;
  assign n583_o = acr[4:2]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:555:29  */
  assign n585_o = n583_o == 3'b001;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:555:40  */
  assign n587_o = n583_o == 3'b101;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:555:40  */
  assign n588_o = n585_o | n587_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:555:48  */
  assign n590_o = n583_o == 3'b100;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:555:48  */
  assign n591_o = n588_o | n590_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:554:29  */
  always @*
    case (n591_o)
      1'b1: n594_o = 1'b1;
      default: n594_o = 1'b0;
    endcase
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:554:29  */
  always @*
    case (n591_o)
      1'b1: n596_o = 1'b1;
      default: n596_o = tmr_b_timer_b_reload_lo;
    endcase
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:553:25  */
  assign n598_o = n582_o ? n594_o : 1'b0;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:546:21  */
  assign n599_o = n606_o ? n596_o : tmr_b_timer_b_reload_lo;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:562:56  */
  assign n601_o = timer_b_count - 16'b0000000000000001;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:546:21  */
  assign n602_o = n569_o ? n601_o : timer_b_count;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:546:21  */
  assign n604_o = n569_o ? n598_o : 1'b0;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:546:21  */
  assign n606_o = n582_o & n569_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:546:21  */
  assign n607_o = n577_o & n569_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:546:21  */
  assign n609_o = n569_o ? n579_o : 1'b0;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:565:67  */
  assign n611_o = timer_b_latch[7:0]; // extract
  assign n612_o = n602_o[7:0]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:564:21  */
  assign n613_o = tmr_b_timer_b_reload_lo ? n611_o : n612_o;
  assign n614_o = n602_o[15:8]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:564:21  */
  assign n616_o = tmr_b_timer_b_reload_lo ? 1'b0 : n599_o;
  assign n617_o = {n614_o, n613_o};
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:534:17  */
  assign n618_o = falling ? n617_o : timer_b_count;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:534:17  */
  assign n620_o = falling ? n616_o : tmr_b_timer_b_reload_lo;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:534:17  */
  assign n621_o = n607_o & falling;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:571:61  */
  assign n626_o = timer_b_latch[7:0]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:571:46  */
  assign n627_o = {data_in, n626_o};
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:570:17  */
  assign n628_o = write_t2c_h ? n627_o : n618_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:570:17  */
  assign n630_o = write_t2c_h ? 1'b1 : n573_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:575:17  */
  assign n632_o = reset ? 16'b0101010101010000 : n628_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:575:17  */
  assign n634_o = reset ? 1'b0 : n620_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:575:17  */
  assign n636_o = reset ? 1'b0 : n630_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:583:33  */
  assign n646_o = rising & tmr_b_timer_b_timeout;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:526:13  */
  always @(posedge clock)
    n647_q <= n634_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:526:13  */
  always @(posedge clock)
    n648_q <= n636_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:526:13  */
  assign n649_o = falling ? n609_o : tmr_b_timer_b_timeout;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:526:13  */
  always @(posedge clock)
    n650_q <= n649_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:526:13  */
  assign n651_o = rising ? n559_o : tmr_b_pb6_c;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:526:13  */
  always @(posedge clock)
    n652_q <= n651_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:526:13  */
  assign n653_o = rising ? tmr_b_pb6_c : tmr_b_pb6_d;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:526:13  */
  always @(posedge clock)
    n654_q <= n653_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:588:16  */
  assign ser_trigger_serial = n723_o; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:589:16  */
  assign ser_shift_clock_d = n799_q; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:590:16  */
  assign ser_shift_clock = n800_q; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:591:16  */
  assign ser_shift_tick_r = n726_o; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:592:16  */
  assign ser_shift_tick_f = n728_o; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:593:16  */
  assign ser_shift_timer_tick = n802_q; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:594:16  */
  assign ser_bit_cnt = n803_q; // (signal)
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:595:16  */
  assign ser_shift_pulse = n678_o; // (signal)
  assign n657_o = acr[3:2]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:600:13  */
  assign n659_o = n657_o == 2'b10;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:603:13  */
  assign n661_o = n657_o == 2'b00;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:603:22  */
  assign n663_o = n657_o == 2'b01;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:603:22  */
  assign n664_o = n661_o | n663_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:607:48  */
  assign n665_o = ~ser_shift_clock_d;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:607:44  */
  assign n666_o = ser_shift_clock & n665_o;
  assign n667_o = {n664_o, n659_o};
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:599:13  */
  always @*
    case (n667_o)
      2'b10: n669_o = ser_shift_timer_tick;
      2'b01: n669_o = 1'b1;
      default: n669_o = n666_o;
    endcase
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:611:29  */
  assign n670_o = ~shift_active;
  assign n671_o = acr[4:2]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:613:39  */
  assign n673_o = n671_o == 3'b000;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:614:52  */
  assign n674_o = ~ser_shift_clock_d;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:614:48  */
  assign n675_o = ser_shift_clock & n674_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:613:17  */
  assign n677_o = n673_o ? n675_o : 1'b0;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:611:13  */
  assign n678_o = n670_o ? n677_o : n669_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:629:36  */
  assign n683_o = ~shift_active;
  assign n684_o = acr[4:2]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:630:47  */
  assign n686_o = n684_o == 3'b000;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:630:25  */
  assign n688_o = n686_o ? cb1_d1 : 1'b1;
  assign n689_o = acr[3:2]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:635:41  */
  assign n691_o = n689_o == 2'b11;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:638:40  */
  assign n692_o = ~ser_shift_clock;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:637:21  */
  assign n693_o = ser_shift_pulse ? n692_o : ser_shift_clock;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:635:21  */
  assign n694_o = n691_o ? cb1_d1 : n693_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:629:21  */
  assign n695_o = n683_o ? n688_o : n694_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:627:17  */
  assign n696_o = rising ? ser_shift_clock : ser_shift_clock_d;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:627:17  */
  assign n697_o = rising ? n695_o : ser_shift_clock;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:649:17  */
  assign n700_o = reset ? 1'b1 : n696_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:649:17  */
  assign n702_o = reset ? 1'b1 : n697_o;
  assign n708_o = acr[3:2]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:656:44  */
  assign n710_o = n708_o == 2'b11;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:656:26  */
  assign n711_o = n710_o ? 1'b0 : serport_en;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:658:31  */
  assign n712_o = shift_reg[7]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:660:49  */
  assign n713_o = acr[3]; // extract
  assign n714_o = acr[4]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:660:33  */
  assign n715_o = n714_o | n713_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:660:69  */
  assign n716_o = acr[2]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:660:53  */
  assign n717_o = n715_o | n716_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:661:45  */
  assign n719_o = ren | wen;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:661:65  */
  assign n721_o = addr == 4'b1010;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:661:57  */
  assign n722_o = n721_o & n719_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:661:31  */
  assign n723_o = n722_o ? 1'b1 : 1'b0;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:662:25  */
  assign n725_o = ~ser_shift_clock_d;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:662:43  */
  assign n726_o = n725_o & ser_shift_clock;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:663:43  */
  assign n727_o = ~ser_shift_clock;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:663:39  */
  assign n728_o = ser_shift_clock_d & n727_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:671:43  */
  assign n733_o = addr == 4'b1010;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:671:34  */
  assign n734_o = n733_o & wen;
  assign n735_o = acr[4]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:673:41  */
  assign n736_o = ser_shift_tick_f & n735_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:674:47  */
  assign n737_o = shift_reg[6:0]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:674:71  */
  assign n738_o = shift_reg[7]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:674:60  */
  assign n739_o = {n737_o, n738_o};
  assign n740_o = acr[4]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:675:36  */
  assign n741_o = ~n740_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:675:41  */
  assign n742_o = ser_shift_tick_r & n741_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:676:47  */
  assign n743_o = shift_reg[6:0]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:676:60  */
  assign n744_o = {n743_o, cb2_d1};
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:675:21  */
  assign n745_o = n742_o ? n744_o : shift_reg;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:673:21  */
  assign n746_o = n736_o ? n739_o : n745_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:671:21  */
  assign n747_o = n734_o ? data_in : n746_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:670:17  */
  assign n748_o = falling ? n747_o : shift_reg;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:668:17  */
  assign n750_o = reset ? 8'b11111111 : n748_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:683:42  */
  assign n753_o = ~shift_active;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:683:38  */
  assign n754_o = ser_shift_tick_r & n753_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:683:59  */
  assign n755_o = n754_o & rising;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:683:70  */
  assign n756_o = n755_o & serport_en;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:689:37  */
  assign n760_o = ~shift_active;
  assign n761_o = acr[4:2]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:689:66  */
  assign n763_o = n761_o != 3'b000;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:689:43  */
  assign n764_o = n763_o & n760_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:690:25  */
  assign n766_o = ser_trigger_serial ? 1'b1 : shift_active;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:690:25  */
  assign n768_o = ser_trigger_serial ? 3'b111 : ser_bit_cnt;
  assign n769_o = acr[3:2]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:695:42  */
  assign n771_o = n769_o == 2'b00;
  assign n772_o = acr[4]; // extract
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:697:49  */
  assign n773_o = ser_shift_clock & ser_shift_pulse;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:698:40  */
  assign n774_o = {29'b0, ser_bit_cnt};  //  uext
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:698:40  */
  assign n776_o = n774_o == 32'b00000000000000000000000000000000;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:701:52  */
  assign n777_o = {29'b0, ser_bit_cnt};  //  uext
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:701:52  */
  assign n779_o = n777_o - 32'b00000000000000000000000000000001;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:701:44  */
  assign n780_o = n779_o[2:0];  // trunc
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:697:25  */
  assign n782_o = n784_o ? 1'b0 : shift_active;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:698:29  */
  assign n783_o = n776_o ? ser_bit_cnt : n780_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:697:25  */
  assign n784_o = n776_o & n773_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:697:25  */
  assign n785_o = n773_o ? n783_o : ser_bit_cnt;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:695:25  */
  assign n786_o = n771_o ? n772_o : n782_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:695:25  */
  assign n787_o = n771_o ? ser_bit_cnt : n785_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:689:21  */
  assign n788_o = n764_o ? n766_o : n786_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:689:21  */
  assign n789_o = n764_o ? n768_o : n787_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:688:17  */
  assign n790_o = falling ? n788_o : shift_active;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:688:17  */
  assign n791_o = falling ? n789_o : ser_bit_cnt;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:707:17  */
  assign n793_o = reset ? 1'b0 : n790_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:707:17  */
  assign n795_o = reset ? 3'b000 : n791_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:625:13  */
  always @(posedge clock)
    n799_q <= n700_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:625:13  */
  always @(posedge clock)
    n800_q <= n702_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:625:13  */
  assign n801_o = falling ? timer_b_tick : ser_shift_timer_tick;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:625:13  */
  always @(posedge clock)
    n802_q <= n801_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:687:13  */
  always @(posedge clock)
    n803_q <= n795_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:214:9  */
  always @(posedge clock)
    n804_q <= n411_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:214:9  */
  always @(posedge clock)
    n805_q <= port_a_i;
  initial
    n805_q = 8'b00000000;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:214:9  */
  always @(posedge clock)
    n806_q <= port_b_i;
  initial
    n806_q = 8'b00000000;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:214:9  */
  always @(posedge clock)
    n807_q <= n413_o;
  initial
    n807_q = 7'b0000000;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:214:9  */
  always @(posedge clock)
    n808_q <= n415_o;
  initial
    n808_q = 7'b0000000;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:214:9  */
  assign n809_o = {n551_o, n646_o, n63_o, n67_o, n756_o, n55_o, n59_o};
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:214:9  */
  always @(posedge clock)
    n810_q <= n417_o;
  initial
    n810_q = 16'b0101010101010000;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:214:9  */
  always @(posedge clock)
    n811_q <= n421_o;
  initial
    n811_q = 16'b0101010101010000;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:468:13  */
  always @(posedge clock)
    n812_q <= n538_o;
  initial
    n812_q = 16'b0101010101010000;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:526:13  */
  always @(posedge clock)
    n813_q <= n632_o;
  initial
    n813_q = 16'b0101010101010000;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:526:13  */
  assign n814_o = falling ? n604_o : timer_b_tick;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:526:13  */
  always @(posedge clock)
    n815_q <= n814_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:214:9  */
  always @(posedge clock)
    n816_q <= n423_o;
  initial
    n816_q = 8'b00000000;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:214:9  */
  always @(posedge clock)
    n817_q <= n425_o;
  initial
    n817_q = 8'b00000000;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:667:13  */
  always @(posedge clock)
    n818_q <= n750_o;
  initial
    n818_q = 8'b00000000;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:214:9  */
  assign n819_o = n122_o ? port_a_c : ira;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:214:9  */
  always @(posedge clock)
    n820_q <= n819_o;
  initial
    n820_q = 8'b00000000;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:214:9  */
  assign n821_o = n128_o ? port_b_c : irb;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:214:9  */
  always @(posedge clock)
    n822_q <= n821_o;
  initial
    n822_q = 8'b00000000;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:214:9  */
  always @(posedge clock)
    n823_q <= n427_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:214:9  */
  always @(posedge clock)
    n824_q <= n429_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:214:9  */
  always @(posedge clock)
    n825_q <= n431_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:214:9  */
  always @(posedge clock)
    n826_q <= n433_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:214:9  */
  always @(posedge clock)
    n827_q <= n435_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:214:9  */
  always @(posedge clock)
    n828_q <= n437_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:214:9  */
  always @(posedge clock)
    n829_q <= n439_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:214:9  */
  always @(posedge clock)
    n830_q <= n441_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:214:9  */
  always @(posedge clock)
    n831_q <= n443_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:214:9  */
  always @(posedge clock)
    n832_q <= n445_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:214:9  */
  always @(posedge clock)
    n833_q <= n447_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:214:9  */
  always @(posedge clock)
    n834_q <= n449_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:214:9  */
  always @(posedge clock)
    n835_q <= n451_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:214:9  */
  always @(posedge clock)
    n836_q <= n453_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:214:9  */
  always @(posedge clock)
    n837_q <= n455_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:214:9  */
  always @(posedge clock)
    n838_q <= n457_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:687:13  */
  always @(posedge clock)
    n839_q <= n793_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:214:9  */
  always @(posedge clock)
    n840_q <= n458_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:202:9  */
  always @(posedge clock)
    n841_q <= n112_o;
  /* /home/runner/work/C64_MiSTer/C64_MiSTer/rtl/iec_drive/iecdrv_via6522.vhd:202:9  */
  assign n842_o = {n493_o, n489_o};
  assign n843_o = {n498_o, n495_o};
endmodule

